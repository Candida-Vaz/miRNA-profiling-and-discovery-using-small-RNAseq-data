#!/usr/bin/perl

$file = @ARGV[0];
open(IN,"$file");
@arr = <IN>;
chomp(@arr);
open (OUT,">$file.new");
$l = @arr;
for($i=0;$i<$l;$i++)
  {
     if($i%2 == 0)
     {
       print OUT ("$arr[$i]#$arr[$i+1]\n");
     } 
  }
