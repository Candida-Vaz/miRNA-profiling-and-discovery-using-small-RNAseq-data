#!/usr/bin/perl
#AUTHOR CANDIDA VAZ
#This program takes in a list of the blast output files (intronic matched) to get the exact matches
$list = @ARGV[0];
open(IN,"$list");
@arr = <IN>;
chomp(@arr);

foreach $ele(@arr)
{
 print "$ele\n";
 system ("perl pick_out_intronic_best_matches_no_error.pl $ele\n");
 system ("sort $ele.matched_0_error > tmp");
 system ("uniq tmp > $ele.matched_0_error_uniq");
 system ("rm -rf tmp");
}
