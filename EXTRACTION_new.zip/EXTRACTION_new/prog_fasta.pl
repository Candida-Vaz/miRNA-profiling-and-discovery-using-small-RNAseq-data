#!/usr/bin/perl

$file = @ARGV[0];
open(IN,"$file");
@arr = <IN>;
chomp(@arr);
open (OUT,">$file.fasta");
$l = @arr;
for($i=0;$i<$l;$i++)
  {
     ($head,$seq) = split(/\#/,$arr[$i]);
     print OUT ("$head\n$seq\n");
  }
close(IN);
close(OUT);
