#!/usr/bin/perl
##No error case####
#AUTHOR CANDIDA VAZ
#parsing out the hits having aln len == to query length And finds the number of errors = gaps + mismatches keeps it == 0.

$file = @ARGV[0];
open (IN,"$file");
($name,$ext) = split(/\./,$file);
@arr = <IN>;
chomp(@arr);
$len = @arr;
open (OUT,">$file.matched_0_error");

for($i =0; $i <$len; $i++)
  
   {
       
      @ele = split (/\s+/,$arr[$i]);
      @query = split (/\./,$ele[0]);

        print "perid:$ele[2]\n";
        print "aln_len:$ele[3]\n";
        print "q_len:$query[1]\n";
        print "mismatches:$ele[4]\n";
        print "gaps:$ele[5]\n";

           if ($query[1] - $ele[3] == 0) # query length == alignment length
           {
                    $errors = $ele[4]+$ele[5];#gaps+mismatches
                    if($errors ==0)
                    {
                      print OUT ("$arr[$i]\n");
                    }
           }

     
    }

close (IN);
close (OUT);
#############################################################
