#!/usr/bin/perl
#AUTHOR CANDIDA VAZ
#This program takes in a list of the split intergenic not found fasta files to match it with the intronic database
 
$list = @ARGV[0];#the list of the split intergenic_not_found_fasta file
open(IN,"$list");
@arr = <IN>;
chomp(@arr);

foreach $ele(@arr)
{
 print "$ele\n";
 system("./blastall -p blastn -d introns_all_chromosomes_latest -i $ele -m 8 -o $ele.introns.blast");
}

close(IN);
