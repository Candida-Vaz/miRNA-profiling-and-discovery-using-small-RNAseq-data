#!/usr/bin/perl
#AUTHOR CANDIDA VAZ
#This program takes in a list of the intergenic blast output files to parse out the exact matches.

$list = @ARGV[0];#the list of the matched files (blast output files)
open(IN,"$list");
@arr = <IN>;
chomp(@arr);

foreach $ele(@arr)
{
 print "$ele\n";
 system("perl pick_out_intergenic_best_matches_no_error.pl $ele\n");
 system ("sort $ele.matched_0_error > tmp");
 system ("uniq tmp > $ele.matched_0_error_uniq");
 system ("rm -rf tmp");
}
close(IN);
