#/usr/bin/perl
  
  $file = @ARGV[0];# the exons_not_found_fasta file
  $name = $file.'_'.'part';
  system ("split -l 40000 $file $name");
  system ("ls $name* > list_split_files");
  system ("perl automate_blast_intronic.pl list_split_files");
  system ("ls *.introns.blast > list_blast_files");
  system ("perl automate_parser_intronic.pl list_blast_files ");
  system ("cat *.matched_0_error_uniq >> matched_0_error_uniq ");
  system ("perl extracting_from_intronic.pl matched_0_error_uniq");
  system ("perl prog_uniquing_out.pl matched_0_error_uniq.intronic_extended_exact_matches_for_folding");
  system ("sort matched_0_error_uniq.intronic_extended_exact_matches_for_folding.new > s_matched_0_error_uniq.intronic_extended_exact_matches_for_folding.new");
  system ("uniq s_matched_0_error_uniq.intronic_extended_exact_matches_for_folding.new > u_s_matched_0_error_uniq.intronic_extended_exact_matches_for_folding.new");
  system ("prog_fasta.pl u_s_matched_0_error_uniq.intronic_extended_exact_matches_for_folding.new");
