#AUTHOR CANDIDA VAZ
#this program takes in the parsed blast file ( with 100% matches) opens the corresponding intergenic file to extract the +-70 extra regions ..to fold 
#!/usr/bin/perl

$file = @ARGV[0]; ###enter the file which has the exact hits
open (IN,"$file");

@arr = <IN>;
chomp(@arr);
open (OUT,">$file.intergenic_extended_exact_matches_for_folding");#input for the folding algorithms
open (OUT1,">$file.err");#reject
foreach $ele (@arr)
  {
    @columns = split(/\s/,$ele);
    $compare = '>'.$columns[1];# the subject line : is the header in the intergenic file
    @subj  = split(/\./,$columns[1]);
    $name = $subj[0].'.'.'new_ig';# creating the name of the intergenic file which matched
    print "coressp:intergenic_file_to_open:$name\n"; 
    open (FIN,"$name");
    @filecomp = <FIN>;
    chomp(@filecomp);
    $len = @filecomp;

    for($i=0;$i<$len;$i++)
        {
           if($i%2 == 0)# the headers of the corresp intergenic file
            {
              if($compare eq $filecomp[$i])#matching the header of the intergenic file with the subject line in blast parsed file
               { 
     ################################################################################################
                 ($tmp,$locus) = split(/\[/,$columns[1]); #getting the start end and size  of the intergenic match
                 ($intg_st,$tintg_end) = split(/\../,$locus);
                  ($intg_end,$tmp1) = split(/\]/,$tintg_end);
                   $intg_size = ($intg_end - $intg_st)+1;
      ######################################################################
                 $seq = $filecomp[$i+1];#getting the intergenic sequence
                 $start = $columns[8];  #getting the sub st 
                 $end = $columns[9];    # getting the sub end
      ##############################positive hit########################################
                  if ($start < $end)
                     {
                       $newst = $start - 70;#extension
                       $newend = $end + 70;
                       $dif = $newend - $newst;
                          if($newst >= 0)
                           {
                               if($newend <=$intg_size)
                                {
                                     $exp_pre = substr($seq,$newst,$dif);
                                     print OUT (">$columns[0].$columns[1]\n$exp_pre\n");
                                }
                                else
                                {
                                    print OUT1 ("$ele\n");
                                }
                           }
                         else
                          {
                            print OUT1 ("$ele\n");
                          }
                     
                      }
#######################################neg hit###########################
                 else
                   {
                     $newst = $end - 70;  #extension
                     $newend = $start + 70;
                     $dif = $newend - $newst;
                         if($newst >=0)
                        {
                             if($newend <=$intg_size)
                            {
                             $exp_pre = substr($seq,$newst,$dif);
                             $rev_exp_pre =revComp($exp_pre);
                             print OUT (">rr:$columns[0].$columns[1]\n$rev_exp_pre\n");
                            }
                             else
                                {
                                    print OUT1 ("$ele\n");
                                }
                        }
                       else
                         {
                           print OUT1 ("$ele\n");
                         }
                    }
 ##########################################################################                
              }
          }
      }
          close (FIN);
         
     }

####################################################################################################################################
sub revComp {     # SUBROUTINE DEFINITION TO

   $tmpSeq = $_[0];         # CREATE THE REVERSE COMPLEMENT

my  @arr = split(//,$tmpSeq);                        
  $l = @arr ;                    

  $seqRC = "";

  

for($I = $l -1; $I >= 0; $I--) 

     {
           if($arr[$I] eq "a")    { $seqRC .= "t"; }

           elsif($arr[$I] eq "c") { $seqRC .= "g"; }

           elsif($arr[$I] eq "g") { $seqRC .= "c"; }

           elsif($arr[$I] eq "t")  { $seqRC .= "a"; }
     
           else { 
                      $seqRC .= "n";

                     
                }

      
   }

   return($seqRC);

}
  
          close (IN);
          close (OUT);
          close (OUT1);
###################################################################################################################################
