#!/usr/bin/perl
#AUTHOR CANDIDA VAZ
#This program takes in the list of the split exon not found fasta file to match it with the intergenic sequences.

$list = @ARGV[0];
open(IN,"$list");
@arr = <IN>;
chomp(@arr);
foreach $ele(@arr)
{
 print "$ele\n";
 system("./blastall -p blastn -d intergenic_all_chromosomes_latest -i $ele -m 8 -o $ele.intg.blast");
}
close(IN);
