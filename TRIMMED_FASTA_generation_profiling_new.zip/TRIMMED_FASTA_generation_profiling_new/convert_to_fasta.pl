#!/usr/bin/perl
#AUTHOR CANDIDA VAZ
# if the trimmed file is provided in form of two columns :first having the trimmed sequence and the other having the frequency:then use this program to convert that file into fasta format

$file = @ARGV[0];#the trimmed file
open(IN,"$file");
@arr = <IN>;
chomp(@arr);
$len = @arr;
open (OUT,">$file.fasta");
open (OUT1,">$file.count");# get the total clone count for calculating tpm
$count =0;
for($i=0;$i<$len;$i++)
  {
     ($seq,$freq) = split(/\s/,$arr[$i]); #splitting the sequence and frequency
      @elseq = split(//,$seq); #taking the length of the sequence
      $l = @elseq;
     print OUT (">$i.$l.$freq\n$seq\n"); #ser no.length.frequency : uniq id for the seq : next line is seq
     $count = $count + $freq;
 }
      print OUT1 ("$count\n");
close(IN);
close (OUT);
close (OUT1); 
