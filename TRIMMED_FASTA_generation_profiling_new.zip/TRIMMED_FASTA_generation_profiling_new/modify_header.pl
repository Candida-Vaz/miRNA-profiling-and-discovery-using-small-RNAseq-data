#!/usr/bin/perl
#AUTHOR CANDIDA VAZ
#modify the header of the fasta file of the mature mirnas


$file = @ARGV[0];#THE MATURE MIRNA FILE
open(IN,"$file");
@arr=<IN>;
chomp(@arr);
$len= @arr;
open(OUT,">$file.mod.head");
for($i=0;$i<$len;$i++)
  {
    if($i%2==0)
      {
           ($name,$tmp) = split(/\s/,$arr[$i]);
           $seq = $arr[$i+1];
           @string = split(//,$seq);
           $len_str = @string;
           print OUT ("$name.$len_str\n$seq\n");#length of the mirna string attached with its name
      }
  }
close(IN);
close(OUT);
