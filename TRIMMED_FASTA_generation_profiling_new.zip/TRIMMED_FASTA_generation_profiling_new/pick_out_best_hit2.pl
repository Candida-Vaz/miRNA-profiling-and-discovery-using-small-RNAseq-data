#!/usr/bin/perl
#Author Candida Vaz
#parsing out the exact hits: from a blast output (tabular) when the query are the mature mirnas and the subject are the trimmed sequences
#used for generating the mature-mirna-expression-profile.

$file = @ARGV[0];
open (IN,"$file");
@arr = <IN>;
chomp(@arr);
$len = @arr;
open (OUT,">$file.matched");
open (OUT1,">$file.res");
for($i=0; $i<$len; $i++)
   {
      @ele = split (/\s/,$arr[$i]);
      @query = split (/\./,$ele[0]);
      @subj = split (/\./,$ele[1]);
        print "aln_len:$ele[3]\n";     
        print "q_len:$query[1]\n";
        print "s_len$subj[2]\n"; # When in the header of the subject file the frequency is before the length.
      if ($query[1] == $subj[2]) #query_length = subject_length
         {
           if ($query[1] == $ele[3]) #query length == alignment length
              {
                if ($ele[2] == 100 ) #percentage identity =100%
                {  
                  print OUT ("$arr[$i]\n");
                  print OUT1 ("$query[0]\t$subj[1]\n");###prints out the exact match with the frequency
                }
              }
         }  
    }
close(IN);
close(OUT);
close(OUT1);
################################################################################################################
