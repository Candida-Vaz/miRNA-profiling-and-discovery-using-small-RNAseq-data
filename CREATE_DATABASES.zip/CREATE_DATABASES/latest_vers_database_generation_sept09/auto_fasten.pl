#!/usr/bin/perl
#this program is used to fasten(put in a single line)the fasta file.Creates output :.red file
print "Enter the list of the fasta files to fasten\n";

$name = <STDIN>;

open (IN,"$name");

@arr= <IN>;
chomp(@arr);
foreach $t (@arr)
  {
      system ("perl fastenfasta.pl $t $t.red");
  }

close(IN);
