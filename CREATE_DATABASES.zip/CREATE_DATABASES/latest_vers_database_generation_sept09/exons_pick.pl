#!/usr/bin/perl
#use strict;
#PROGRAM PICKS UP EXONS and genes (mRNA only)####################THIS IS THE LATEST VERSION##########################GIVES SEPERATE and CONCATENATED FILES###########

#AUTHOR : CANDIDA VAZ######################
#MAY 08
#updated:july,August27th 08.

print "Enter the list of the genbank files";

$list = <STDIN>;#gbks file eq:chr1_gbks
chomp($list);
($list_name,$emp) = split(/\_/,$list);
open (IN,"$list") or die "sorry can't open it\n";
@listarray = <IN>;
open (OUTTOG,">$list_name.exons");#concatenated file :for full chromosome
###########################genbank file open #######################################################################################################
foreach $element (@listarray)
{
($chr_name,$contig_no,$ext) = split (/\./,$element);
$fasno = $contig_no +1;
$title = $chr_name."\.".$fasno;


print "extracting****from****$chr_name****contigno****$contig_no\n";


print "the fasta file is :$title\n";
$ext1 = ".fasta";
$ext2 = ".red";
$fastafile = $title.$ext1.$ext2;

open (IN1,"$element") or die "sorry cant open the genbank file\n";
my @arr = <IN1>;

$l_a = @arr;

chomp (@arr);

open (OUT,">$chr_name.$contig_no.exons");#separate files contig wise
print " the name of the  corresponding fasta file is $fastafile\n";

##########################################################fastafile open ###################################################################
open (IN2,"$fastafile") or die "cant open fasta";

@fasarr = <IN2>;

chomp (@fasarr);

$len = @fasarr;

#########################################FINISH WITH OPENING AND COLLECTING DATA############################################################
#########################################################BEGIN WITH PARSING ################################################################
for (my $i=0;$i<$l_a;$i++)
  { 
       
       
  if ($arr[$i] =~ /\s+mRNA/ ||$arr[$i] =~ /\s+exon/)
         {   
                @splarr = ();  
                @imp = ();
               (@splarr) = split (/\s+/,$arr[$i]);
               $size = @splarr;
               (@imp ) = split (/\(/,$splarr[2]);
               $limp = @imp;
                 if ($limp == 3)   # this is where we find the complement join statement
                    {
                       if ($imp[0] =~ /complement/)
                           { 
                             if ($imp[2] =~ /\)\)$/) # this is where we check if the gene string is complete or not.
                                     {
                                           @nar = (); 
                                          ($tmpq,$spl,$extra)= split(/\"/,$arr[$i+1]);#~~~~~~~~~~~~~~~desc1  
                                           ($real_imp,$tmp_t) = split(/\)/,$imp[2]);
                                           (@nar) = split (/\,/,$real_imp);# collecting the exons by splitting with comma
                                            $Gene_1 = ();
                                            $header_1 = $chr_name.'.'.$contig_no.'.'.$splarr[1].'.'.'revcom';
                                            $limits = @nar;
                                            for ($z =0;$z<$limits;$z++)
                                                    {
                                                        ($st[$z],$end[$z]) = split (/\../,$nar[$z]);#splitting the exon loci into start and end
                                                          if ($st[$z] =~ /^</ && $end[$z] =~ /^>/)
                                                           {
                                                              ($tmps[$z],$nst[$z]) = split(/\</,$st[$z]);
                                                              ($tmpe[$z],$nend[$z]) = split(/\>/,$end[$z]);
                                                               $dif = $nend[$z] - $nst[$z];
                                                               $exon1 = substr ($fasarr[1],$nst[$z]-1,$dif+1);
                                                               $header_1 = $header_1.'.'.$spl.'.'.$st[$z].'.'.$end[$z]; #apending the seperated exns together
                                                               $Gene_1 = $Gene_1.$exon1;
                                                           }
                                                    
                                                         elsif ($st[$z] =~ /^</ && $end[$z] !~ /^>/)
                                                           {
                                                              ($tmps[$z],$nst[$z]) = split(/\</,$st[$z]);
                                                               $dif = $end[$z] - $nst[$z];
                                                               $exon1 = substr ($fasarr[1],$nst[$z]-1,$dif+1);
                                                               $header_1 = $header_1.'.'.$spl.'.'.$st[$z].'.'.$end[$z]; #apending the seperated exns together
                                                               $Gene_1 = $Gene_1.$exon1; 
                                                           }
                                                    
                                                        
                                                         

                                                            elsif ($end[$z] =~ /^>/ && $st[$z] !~ /^</)
                                                           {
                                                              ($tmpe[$z],$nend[$z]) = split(/\>/,$end[$z]);
                                                               $dif = $nend[$z] - $st[$z];
                                                               $exon1 = substr ($fasarr[1],$st[$z]-1,$dif+1);
                                                               $header_1 = $header_1.'.'.$spl.'.'.$st[$z].'.'.$end[$z]; #apending the seperated exns together
                                                               $Gene_1 = $Gene_1.$exon1;
                                                             
                                                           }
                                                            
                                                       
                                                         else
                                                            {
                                                              $dif = $end[$z] - $st[$z]; 
                                                              $exon1 = substr ($fasarr[1],$st[$z]-1,$dif+1);
                                                              $header_1 = $header_1.'.'.$spl.'.'.$st[$z].'.'.$end[$z]; #apending the seperated exns together
                                                              $Gene_1 = $Gene_1.$exon1;
                                                             }
                                                                                                                  
                                                       
                                                      
                                                      }
                                                              $Gene_1_fin = revComp ($Gene_1); # this is the complement after join *
                                                              print OUT (">$header_1\n$Gene_1_fin\n");
                                                              print OUTTOG (">$header_1\n$Gene_1_fin\n");
                  
                                      }
                           else {       #if the gene string is not complete
                                           
                                                                       @tmp = ();
                                                                      @comparr = ();
                                                                      @fullarr = ();  
                                                                       $full = ();
                                                                       $new1 = ();
                                                                       $cv1 =();
                                               
                                              
                                               for($x =1; $x<=$l_a; $x++) #checking nextlines after the string
                                                                     
                                                 {                   
                                                     
                                                    if ($arr[$i+$x] =~ /\)\)$/) #checking for the closing bracket
                                                      {   
                                                          ($tmpq,$spl,$extra)= split(/\"/,$arr[$i+$x+1]);#~~~~~~~~~~~~~desc2
                                                               if($x==1)
                                                                {
                                                                   
                                                                    ($space1,$genestring1) = split(/\s+/,$arr[$i+$x]);
                                                                     $cv1 = $genestring1;
                                                                     $new1 = $imp[2];

                                                                     last;
                                                                }
                                                                else
                                                               {
                                                                  ($space,$genestring) = split(/\s+/,$arr[$i+$x]);
                                                                   $cv1 = $genestring;
                                                                  last;
                                                                }
                                                     }
                                                     else
                                                    {   
                                                        ($space2,$genestring2) = split(/\s+/,$arr[$i+$x]);
                                                        $new1 = $imp[2].$genestring2;#here picking all the intermediate lines
                                                         $imp[2] = $new1;
                                                       
                                                     }
                                                 
                                                       }
                                              push (@tmp,$new1);
                                       
                                                 @comparr =(@tmp,$cv1);
                                                
                                  
                                                 $size = @comparr;
                                                
                                                 $full = $comparr[0].$comparr[1];
                                  
                                                 ($real_full,$tmp_u) = split(/\)/,$full);
                                                 @fullarr = split(/\,/,$real_full);
                                                 $siz_full = @fullarr;
                                            
                                                  $header_2 = $chr_name.'.'.$contig_no.'.'.$splarr[1].'.'.'revcom';
                                                  $Gene_2 =  ();
                                                 
                                                
                                                  for ($z=0;$z<$siz_full;$z++)
   
                                                     {
                                                           ($st[$z],$end[$z]) = split (/\../,$fullarr[$z]);#splitting
                                                           
                                                             if ($st[$z] =~ /^</ && $end[$z] =~ /^>/)
                                                           {
                                                              ($tmps[$z],$nst[$z]) = split(/\</,$st[$z]);
                                                              ($tmpe[$z],$nend[$z]) = split(/\>/,$end[$z]);
                                                               $dif = $nend[$z] - $nst[$z];
                                                               $exon2 = substr ($fasarr[1],$nst[$z]-1,$dif+1);
                                                               $header_2 = $header_2.'.'.$spl.'.'.$st[$z].'.'.$end[$z]; #apending the seperated exns together
                                                               $Gene_2 = $Gene_2.$exon2;
                          
                                                                
                                                           }
                                                            elsif ($st[$z] =~ /^</ && $end[$z] !~ /^>/)
                                                           {
                                                              ($tmps[$z],$nst[$z]) = split(/\</,$st[$z]);
                                                               $dif = $end[$z] - $nst[$z];
                                                               $exon2 = substr ($fasarr[1],$nst[$z]-1,$dif+1);
                                                               $header_2 = $header_2.'.'.$spl.'.'.$st[$z].'.'.$end[$z]; #apending the seperated exns together
                                                               $Gene_2 = $Gene_2.$exon2;
                                                              
                                                           }
                                                    
                                                        

                                                            elsif ($end[$z] =~ /^>/ && $st[$z] !~ /^</)
                                                           {
                                                              ($tmpe[$z],$nend[$z]) = split(/\>/,$end[$z]);
                                                               $dif = $nend[$z] - $st[$z];
                                                               $exon2 = substr ($fasarr[1],$st[$z]-1,$dif+1);
                                                               $header_2 = $header_2.'.'.$spl.'.'.$st[$z].'.'.$end[$z]; #apending the seperated exns together
                                                               $Gene_2 = $Gene_2.$exon2;
                                                           }
                                                            
                                                       
                                                         else
                                                            {
                                                              $dif = $end[$z] - $st[$z]; 
                                                              $exon2 = substr ($fasarr[1],$st[$z]-1,$dif+1);
                                                              $header_2 = $header_2.'.'.$spl.'.'.$st[$z].'.'.$end[$z]; #apending the seperated exns together
                                                              $Gene_2 = $Gene_2.$exon2;
                                                        
                                                             }
                                                     }
                                            $Gene_2_fin = revComp ($Gene_2); # this is the complement after join *
                                            print OUT (">$header_2\n$Gene_2_fin\n"); 
                                            print OUTTOG  (">$header_2\n$Gene_2_fin\n");          
                                   }
                             }

                       }

######################################## HERE THE COMPLEMENT JOIN OPERATIONS FINISH######################################################################

################################################################BEGIN WITH THE JOIN ONLY OPERATION######################################################

          elsif($limp==2) 
            {  
                      if ($imp[0] =~ /join/)
                       {     
                         
                            if ($imp[1] =~ /\)$/)
                               {
                                  @nar2 = ();
                                   ($tmpq,$spl,$extra)= split(/\"/,$arr[$i+1]);#~~~~~~~~~~~desc3
                                
                                    ($real_impj,$tmp_v) = split(/\)/,$imp[1]);
                                   (@nar2) = split (/\,/,$real_impj);# collecting the exons by splitting with comma
                                    $limitsj = @nar2;
                                     $Gene_3 = ();
                                     $header_3 = $chr_name.'.'.$contig_no.'.'.$splarr[1].'.'.'join';
                                     for ($z=0; $z<$limitsj;$z++)
                                              {    
                                                   ($st[$z],$end[$z]) = split (/\../,$nar2[$z]);
                                                    if ($st[$z] =~ /^</ && $end[$z] =~ /^>/)
                                                           {
                                                               
                                                              ($tmps[$z],$nst[$z]) = split(/\</,$st[$z]);
                                                              ($tmpe[$z],$nend[$z]) = split(/\>/,$end[$z]);
                                                               $dif = $nend[$z] - $nst[$z];
                                                               $exon1 = substr ($fasarr[1],$nst[$z]-1,$dif+1);
                                                               $header_3 = $header_3.'.'.$spl.'.'.$st[$z].'.'.$end[$z]; #apending the seperated exns together
                                                               $Gene_3 = $Gene_3.$exon1;
                                                                 
                                                           }
                                                   elsif ($st[$z] =~ /^</ && $end[$z] !~ /^>/)
                                                           {
                                                              
                                                              ($tmps[$z],$nst[$z]) = split(/\</,$st[$z]);
                                                               $dif = $end[$z] - $nst[$z];
                                                               $exon1 = substr ($fasarr[1],$nst[$z]-1,$dif+1);
                                                               $header_3 = $header_3.'.'.$spl.'.'.$st[$z].'.'.$end[$z]; #apending the seperated exns together
                                                               $Gene_3 = $Gene_3.$exon1;
                                                                
                                                           }
                                                    
                                                        
                                                        

                                                            elsif ($end[$z] =~ /^>/ && $st[$z] !~ /^</)
                                                           {
                                                              ($tmpe[$z],$nend[$z]) = split(/\>/,$end[$z]);
                                                               $dif = $nend[$z] - $st[$z];
                                                               $exon1 = substr ($fasarr[1],$st[$z]-1,$dif+1);
                                                               $header_3 = $header_3.'.'.$spl.'.'.$st[$z].'.'.$end[$z]; #apending the seperated exns together
                                                               $Gene_3 = $Gene_3.$exon1;
                                                           }
                                                            
                                                       
                                                         else
                                                            {
                                                              $dif = $end[$z] - $st[$z]; 
                                                              $exon1 = substr ($fasarr[1],$st[$z]-1,$dif+1);
                                                              $header_3 = $header_3.'.'.$spl.'.'.$st[$z].'.'.$end[$z]; #apending the seperated exns together
                                                              $Gene_3 = $Gene_3.$exon1;
                                                               
                                                             }
                                                               
                                                

                                               }
                                                   print OUT (">$header_3\n$Gene_3\n");
                                                   print OUTTOG (">$header_3\n$Gene_3\n");
                              }


                        else 
                              {
                                                   @jointmp = ();
                                                   @comparry = ();
                                                   @fullarry = ();
                                                   $fool = ();
                                                   $new2 = ();
                                                   $cv2 = ();
                                  #if the gene string is not complete

                                               for($x =1; $x<=$l_a; $x++) #checking nextlines after the string
                                                 {

                                                    if ($arr[$i+$x] =~ /\)/) #checking for the closing bracket
                                                      {
                                                            ($tmpq,$spl,$extra)= split(/\"/,$arr[$i+$x+1]);#~~~~~~~~~~~~~~~desc4
                                                      
                                                          if($x==1)
                                                                {

                                                                    
                                                                     ($space3,$genestring3) = split(/\s+/,$arr[$i+$x]);
                                                                     $cv2=$genestring3;
                                                                     $new2 = $imp[1];
                                                                     last;

                                                                }
                                                                else
                                                               {
                                                                 
                                                                  ($space4,$genestring4) = split(/\s+/,$arr[$i+$x]);
                                                                   $cv2 = $genestring4;
                                         
                                                                   last;
                                                               }
                                                      }
                                                     else
                                                    {

                                                        ($space5,$genestring5) = split(/\s+/,$arr[$i+$x]);
                                                        $new2 = $imp[1].$genestring5;#here picking all the intermediate lines
                                                         $imp[1] = $new2;
                                                    }

                                            }

                                             push (@jointmp,$new2);
                                             @comparry =(@jointmp,$cv2);
                                         


                                              $sizej = @comparry;
 
                                              $fool = $comparry[0].$comparry[1];
                                            
#                                          
                                    
                                                 ($real_fool,$tmp_w) = split(/\)/,$fool); 
                                               @fullarry = split (/\,/,$real_fool);
                                               $siz_fullj = @fullarry;
                                               $Gene_4 = ();
                                               $header_4  = $chr_name.'.'.$contig_no.'.'.$splarr[1].'.'.'join';
                                           
                                               for ($z=0;$z<$siz_fullj;$z++)

                                                     {
                                                           ($st[$z],$end[$z]) = split (/\../,$fullarry[$z]);#splitting
                                                               if ($st[$z] =~ /^</ && $end[$z] =~ /^>/)
                                                           {
                                                              
                                                              ($tmps[$z],$nst[$z]) = split(/\</,$st[$z]);
                                                              ($tmpe[$z],$nend[$z]) = split(/\>/,$end[$z]);
                                                               $dif = $nend[$z] - $nst[$z];
                                                               $exon2 = substr ($fasarr[1],$nst[$z]-1,$dif+1);
                                                                 $header_4 = $header_4.'.'.$spl.'.'.$st[$z].'.'.$end[$z]; #apending the seperated exns together
                                                                 $Gene_4 = $Gene_4.$exon2;
                                                                 
                                                           }
                                                               elsif ($st[$z] =~ /^</ && $end[$z] !~ /^>/)
                                                           {
                                                                
                                                              ($tmps[$z],$nst[$z]) = split(/\</,$st[$z]);
                                                               $dif = $end[$z] - $nst[$z];
                                                               $exon2 = substr ($fasarr[1],$nst[$z]-1,$dif+1);
                                                                 $header_4 = $header_4.'.'.$spl.'.'.$st[$z].'.'.$end[$z]; #apending the seperated exns together
                                                                 $Gene_4 = $Gene_4.$exon2;
                                                                

                                                           }
                                                    
                                                      

                                                            elsif ($end[$z] =~ /^>/ && $st[$z] !~ /^</)
                                                           {
                                                              ($tmpe[$z],$nend[$z]) = split(/\>/,$end[$z]);
                                                               $dif = $nend[$z] - $st[$z];
                                                               $exon2 = substr ($fasarr[1],$st[$z]-1,$dif+1);
                                                                 $header_4 = $header_4.'.'.$spl.'.'.$st[$z].'.'.$end[$z]; #apending the seperated exns together
                                                                 $Gene_4 = $Gene_4.$exon2;
                                                                 

                                                           }
                                                            
                                                       
                                                         else
                                                            {
                                                              $dif = $end[$z] - $st[$z]; 
                                                              $exon2 = substr ($fasarr[1],$st[$z]-1,$dif+1);
                                                                 $header_4 = $header_4.'.'.$spl.'.'.$st[$z].'.'.$end[$z]; #apending the seperated exns together
                                                                 $Gene_4 = $Gene_4.$exon2;
                                                               
 
                                                             }
                                                            
                                                             

                                                     }
                                             
                                           print OUT (">$header_4\n$Gene_4\n");    
                                           print OUTTOG (">$header_4\n$Gene_4\n"); 
                                              
                                   }
                                           


                    
                   }
####################################################################FINISH WITH JOIN ##########################ENTER NO INTRONS SECTION###################################
                else  #limp ==2 but there are no introns and the gene is on the negative strand (COMPLEMENT NEGATIVE SIMPLE)
                     {
                         ($real_impk,$tmp_x) = split(/\)/,$imp[1]);
                                if($real_impk =~ /\d+..\d+/)
                                  {
                                     $Gene_5 = ();
                                     $header_5 = $chr_name.'.'.$contig_no.'.'.$splarr[1].'.'.'compsimple';
                               ($tmpq,$spl,$extra)= split(/\"/,$arr[$i+1]);#~~~~~~~~~~~~~~~~~~~~desc5
                         
                                  
                                                   ($st,$end) = split (/\../,$real_impk);#splitting the exon loci into start and end
                                                        if ($st =~ /^</ && $end =~ /^>/)
                                                           {
                                                               
                                                              ($tmps,$nst) = split(/\</,$st);
                                                              ($tmpe,$nend) = split(/\>/,$end);
                                                               $dif = $nend - $nst;
                                                             $exoncompsimple = substr ($fasarr[1],$nst-1,$dif+1);
                                                             $fin_exoncompsimple = revComp ($exoncompsimple);
                                                                 $header_5 = $header_5.'.'.$spl.'.'.$st.'.'.$end;
                                                                 $Gene_5 = $fin_exoncompsimple;
                                                           
                                                           }
                                                        elsif ($st =~ /^</ && $end !~ /^>/)
                                                           {
                                                                 
                                                                ($tmps,$nst) = split(/\</,$st);
                                                                 $dif = $end - $nst;
                                                                 $exoncompsimple = substr ($fasarr[1],$nst-1,$dif+1);
                                                                 $fin_exoncompsimple = revComp ($exoncompsimple);
                                                                 $header_5 = $header_5.'.'.$spl.'.'.$st.'.'.$end; 
                                                                 $Gene_5 = $fin_exoncompsimple;
                                                                
   
                                                           }
                                                    
                                                        

                                                            elsif ($end =~ /^>/ && $st !~ /^</)
                                                           {
                                                              ($tmpe,$nend) = split(/\>/,$end);
                                                               $dif = $nend - $st ;
                                                               $exoncompsimple  = substr ($fasarr[1],$st-1,$dif+1);
                                                               $fin_exoncompsimple = revComp ($exoncompsimple);
                                                                 $header_5 = $header_5.'.'.$spl.'.'.$st.'.'.$end;
                                                                 $Gene_5 = $fin_exoncompsimple;
                                                                
                                                           }
                                                            
                                                       
                                                         else
                                                            {
                                                               $dif = $end - $st; 
                                                               $exoncompsimple = substr ($fasarr[1],$st-1,$dif+1);
                                                               $fin_exoncompsimple = revComp ($exoncompsimple); 
                                                                 $header_5 = $header_5.'.'.$spl.'.'.$st.'.'.$end;
                                                                 $Gene_5 = $fin_exoncompsimple;
                                                             }
                                             print OUT (">$header_5\n$Gene_5\n");
                                            print OUTTOG (">$header_5\n$Gene_5\n");        
                                        } 
                    }

    }
##################################################################################################################################
else   #$limp ==1 (simplest case) gene with no intron and on positive strand (POSITIVE SIMPLE)
     {
       if($imp[0] =~ /\d+..\d+/)
         {  
           ($tmpq,$spl,$extra)= split(/\"/,$arr[$i+1]);#~~~~~~~~~~~~~~~~desc6
                $Gene_6 = ();
                $header_6 = $chr_name.'.'.$contig_no.'.'.$splarr[1].'.'.'simple';                            
       
                      
                              ($st,$end) = split (/\../,$imp[0]);#splitting the exon loci into start and end
                                                         
                                                          #here picking up exons
                                                          if ($st =~ /^</ && $end =~ /^>/)
                                                           {
                                                      
                                                              ($tmps,$nst) = split(/\</,$st);
                                                              ($tmpe,$nend) = split(/\>/,$end);
                                                               $dif = $nend - $nst;
                                                             $exonsimple = substr ($fasarr[1],$nst-1,$dif+1);
                                                                $header_6 = $header_6.'.'.$spl.'.'.$st.'.'.$end;
                                                                $Gene_6 = $exonsimple;
                                                           }
                                                        elsif ($st =~ /^</ && $end !~ /^>/)
                                                           { 
                                                              ($tmps,$nst) = split(/\</,$st);
                                                          
                                                               $dif = $end - $nst;
                                                               $exonsimple = substr ($fasarr[1],$nst-1,$dif+1);
                                                                 $header_6 = $header_6.'.'.$spl.'.'.$st.'.'.$end;
                                                                 $Gene_6 = $exonsimple;
                                                           }
                                                    
                                                        

                                                            elsif ($end =~ /^>/ && $st !~ /^</)
                                                           {
                                                              ($tmpe,$nend) = split(/\>/,$end);
                                                               $dif = $nend - $st;
                                                              $exonsimple = substr ($fasarr[1],$st-1,$dif+1);
                                                                $header_6 = $header_6.'.'.$spl.'.'.$st.'.'.$end;
                                                                 $Gene_6 = $exonsimple; 
                                                           }
                                                            
                                                       
                                                         else
                                                            {
                                                              $dif = $end - $st; 
                                                              $exonsimple = substr ($fasarr[1],$st-1,$dif+1);
                                                                 $header_6 = $header_6.'.'.$spl.'.'.$st.'.'.$end;
                                                                 $Gene_6 = $exonsimple;
                                                             }
                                                            
                          print OUT (">$header_6\n$Gene_6\n"); 
                          print OUTTOG (">$header_6\n$Gene_6\n");  
               }
      }




      }

 
          }

  } 
 ################################################################################################################################################
sub revComp {     # SUBROUTINE DEFINITION TO

   $tmpSeq = $_[0];         # CREATE THE REVERSE COMPLEMENT

my  @arr = split(//,$tmpSeq);                        
  $l = @arr ;                    

  $seqRC = "";

  

for($I = $l -1; $I >= 0; $I--) 

     {
           if($arr[$I] eq "A")    { $seqRC .= "T"; }

           elsif($arr[$I] eq "C") { $seqRC .= "G"; }

           elsif($arr[$I] eq "G") { $seqRC .= "C"; }

           elsif($arr[$I] eq "T")  { $seqRC .= "A"; }
     
           else { 
                      $seqRC .= "N";

                    
                }

      
   }

   return($seqRC);

}
  
close (IN);
close(IN1);
close (OUT);
close (OUTTOG);
