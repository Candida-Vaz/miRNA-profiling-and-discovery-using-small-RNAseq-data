#!/usr/bin/perl
#use strict;
#PROGRAM PICKS UP INTRONS####################

#AUTHOR : CANDIDA VAZ######################
#JAN 08
#updated Nov 08

print "Enter the list of the genbank files";

$list = <STDIN>;

open (IN,"$list") or die "sorry can't open it\n";
@listarray = <IN>;
###########################genbank file open #######################################################################################################
foreach $element (@listarray)
{
($chr_name,$contig_no,$ext) = split (/\./,$element);
$fasno = $contig_no +1;
$title = $chr_name."\.".$fasno;


print "extracting****from****$chr_name****contigno****$contig_no\n";


print "the fasta file is :$title\n";
$ext1 = ".fasta";
$ext2 = ".red";
$fastafile = $title.$ext1.$ext2;

open (IN1,"$element") or die "sorry cant open the genbank file\n";
my @arr = <IN1>;

$l_a = @arr;

chomp (@arr);


open (OUT1,">$chr_name.$contig_no.introns");

print " the name of the  corresponding fasta file is $fastafile\n";

##########################################################fastafile open ############################################################################
open (IN2,"$fastafile") or die "cant open fasta";

@fasarr = <IN2>;

chomp (@fasarr);

$len = @fasarr;
 
#########################################FINISH WITH OPENING AND COLLECTING DATA##########################################################################

#########################################################BEGIN WITH PARSING INTRONS######################################################################

for (my $i=0;$i<$l_a;$i++)
  { 
           
      if ($arr[$i] =~ /\s+mRNA/  || $arr[$i] =~ /\s+tRNA/ ||$arr[$i] =~ /\s+ncRNA/ || $arr[$i] =~ /\s+misc_RNA/)
         {   
                 @splarr =();
                 @imp = ();
               (@splarr) = split (/\s+/,$arr[$i]);
               $size = @splarr;
               (@imp ) = split (/\(/,$splarr[2]);
               $limp = @imp;
                 if ($limp == 3)   # this is where we find the complement join statement
                    {
                         
                         if ($imp[0] =~ /complement/)
                           {
                             if ($imp[2] =~ /\)\)$/) # this is where we check if the gene string is complete or not.
                                     {      
                                               @nar = (); 
                                            ($tmpq,$spl,$extra)= split(/\"/,$arr[$i+1]);#~~~~~~~~~~~~~~~desc1
                                          
                                           (@nar) = split (/\,/,$imp[2]);# collecting the exons by splitting with comma
                                          
                                            $limits = @nar; 
                                            $pre_end = 0;
                                            for ($z =0;$z<$limits;$z++)
                                                    {   
                                                        ($st,$end) = split (/\../,$nar[$z]);#splitting the exon loci into start and end
                                                                $dif = $st - $pre_end;
                                                                if($dif!=$st)
                                                               {
                                                                    $intron1 = substr ($fasarr[1],$pre_end,$dif-1);
                                                                    $fin_intron1 = revComp($intron1);
                                                                    $left1 = $pre_end+1;
                                                                    $right1 = $st-1;
                                                                    print OUT1 (">$chr_name.$contig_no.$splarr[1].$spl.revcom.[$left1..$right1]\n");
                                                                    print OUT1 ( "$fin_intron1\n");
                                                                   
    
                                                               }
                                                                    $pre_end = $end;
                                                      } 

                                      }


                               else {       
                                              
                                               #if the gene string is not complete
                                                                       @tmp = ();
                                                                      @comparr = ();
                                                                      @fullarr = ();
                                                                       $full = ();
                                                                       $new1 = ();
                                                                       $cv1 =();
                                              
                                               for($x =1; $x<=$l_a; $x++) 
                                                 {                                  
                                                    if ($arr[$i+$x] =~ /\)\)$/) #checking for the closing bracket
                                                      {   
                                                         
                                                           ($tmpq,$spl,$extra)= split(/\"/,$arr[$i+$x+1]);#~~~~~~~~~~~~~desc2
                                                          
                                                               if($x==1)
                                                                {  
                                                                    ($space1,$genestring1) = split(/\s+/,$arr[$i+$x]);
                                                                     $cv1 = $genestring1;
                                                                     $new1 = $imp[2];

                                                                     last;
                                                                }

                                                                else
                                                               {
                                                                  
                                                                  ($space,$genestring) = split(/\s+/,$arr[$i+$x]);
                                                                   $cv1 = $genestring;
                                                                  last;
                                                              }
                                                     }
                                                     else
                                                    {   
                                                        ($space2,$genestring2) = split(/\s+/,$arr[$i+$x]);
                                                        $new1 = $imp[2].$genestring2;#here picking all the intermediate lines
                                                         $imp[2] = $new1;
                                                       
                                                     }
                                                 
                                             }
                                              push (@tmp,$new1);
                                              
                                             @comparr =(@tmp,$cv1);
                                  
                                                 $size = @comparr;
                                                 $full = $comparr[0].$comparr[1];
                                                 @fullarr = split(/\,/,$full);
                                                 $siz_full = @fullarr;
                                                   $pre_end =0;
                                                  for ($z=0;$z<$siz_full;$z++)
   
                                                     {
                                                           ($st,$end) = split (/\../,$fullarr[$z]);
                                                                $dif = $st - $pre_end;
                                                                if($dif!=$st)
                                                               {
                                                               $intron2 = substr ($fasarr[1],$pre_end,$dif-1);
                                                               $fin_intron2 = revComp($intron2);
                                                               $left2 = $pre_end+1;
                                                               $right2 = $st -1;
                                                              print OUT1 (">$chr_name.$contig_no.$splarr[1].$spl.revcom.[$left2..$right2]\n");
                                                              print OUT1 ( "$fin_intron2\n");
                                                   
                                                              }
                                                               $pre_end = $end;
                                                           

                                                     }
                                                    
                                   }
                                           
                               

                              }
                       }

######################################## HERE THE COMPLEMENT JOIN OPERATIONS FINISH#########################################################
################################################################BEGIN WITH THE JOIN ONLY OPERATION##########################################
          else 
            {  
                      if ($imp[0] =~ /join/)
                       {     
                      
                            if ($imp[1] =~ /\)$/)
                               {      @nar2 = ();
                                    ($tmpq,$spl,$extra)= split(/\"/,$arr[$i+1]);#~~~~~~~~~~~desc3
                                    
                                  
                                   (@nar2) = split (/\,/,$imp[1]);# collecting the exons by splitting with comma
                                    $limitsj = @nar2;
                                    $pre_end =0;
                                     for ($z=0; $z<$limitsj;$z++)
                                              {    
                                                   ($st,$end) = split (/\../,$nar2[$z]);
                                                                $dif = $st - $pre_end;
                                                                if($dif != $st)
                                                              {
                                                               $intron3 = substr ($fasarr[1],$pre_end,$dif-1);
                                                               $left3 = $pre_end+1;
                                                               $right3 = $st-1;
                                                              print OUT1 (">$chr_name.$contig_no.$splarr[1].$spl.join.[$left3..$right3]\n");
                                                              print OUT1 ( "$intron3\n");
                                                             }
                                                               $pre_end = $end;
                                               }
                              }


                        else 
                              {

                                  #if the gene string is not complete
                                                   @jointmp = ();
                                                   @comparry = ();
                                                   @fullarry = ();
                                                   $fool = ();
                                                   $new2 = ();
                                                   $cv2 = ();
                                               for($x =1; $x<=$l_a; $x++) 
                                                 {        
                                                                    
                                                    if ($arr[$i+$x] =~ /\)/) #checking for the closing bracket
                                                      {
                                                               ($tmpq,$spl,$extra)= split(/\"/,$arr[$i+$x+1]);#~~~~~~~~~~~~~~~desc4
                                                             
                                                          if($x==1)
                                                                {
                                                                     ($space3,$genestring3) = split(/\s+/,$arr[$i+$x]);
                                                                     $cv2=$genestring3;
                                                                     $new2 = $imp[1];
                                                                     last;

                                                                }
                                                                else
                                                                {
                                                                  ($space4,$genestring4) = split(/\s+/,$arr[$i+$x]);
                                                                   $cv2 = $genestring4;
                                                                   last;
                                                               }
                                                      }
                                                     else
                                                    {

                                                        ($space5,$genestring5) = split(/\s+/,$arr[$i+$x]);
                                                        $new2 = $imp[1].$genestring5;#here picking all the intermediate lines
                                                         $imp[1] = $new2;
                                                    }

                                            }

                                             push (@jointmp,$new2);
                                             @comparry =(@jointmp,$cv2);
                                            


                                              $sizej = @comparry;
 
                                              $fool = $comparry[0].$comparry[1];                                    
                                               @fullarry = split (/\,/,$fool);
                                               $siz_fullj = @fullarry;
                                               $pre_end =0;
                                           
                                               for ($z=0;$z<$siz_fullj;$z++)

                                                     {
                                                           ($st,$end) = split (/\../,$fullarry[$z]);
                                                              $dif = $st - $pre_end; 
                                                               if($dif!=$st)
                                                              {
                                                              $intron4 = substr ($fasarr[1],$pre_end,$dif-1);
                                                              $left4 = $pre_end+1;
                                                              $right4 = $st-1;
                                                                print OUT1 (">$chr_name.$contig_no.$splarr[1].$spl.join.[$left4..$right4]\n");                                                              print OUT1 ( "$intron4\n");    
                                                              }
                                                               $pre_end = $end;
                                                             
                                                     }

                                            }
                                 }

                             }


#############################END OF JOIN PART#####################################################################################################



                      }
         }
 
}
   
 ################################################################################################################################################
sub revComp {     # SUBROUTINE DEFINITION TO

   $tmpSeq = $_[0];         # CREATE THE REVERSE COMPLEMENT

my  @arr = split(//,$tmpSeq);                        
  $l = @arr ;                    

  $seqRC = "";

  

for($I = $l -1; $I >= 0; $I--) 

     {
           if($arr[$I] eq "A")    { $seqRC .= "T"; }

           elsif($arr[$I] eq "C") { $seqRC .= "G"; }

           elsif($arr[$I] eq "G") { $seqRC .= "C"; }

           elsif($arr[$I] eq "T")  { $seqRC .= "A"; }
     
           else { 
                      $seqRC .= "N";                    
                }

      
   }

   return($seqRC);

        
  }
      
close (IN);
close(IN1);
close (OUT1);
