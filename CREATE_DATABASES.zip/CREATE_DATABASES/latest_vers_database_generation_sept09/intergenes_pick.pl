#!/usr/bin/perl
#This program is used to pick out the intergenic regions from genbank files of contigs

#Defining all the variables
my $filename = ""; 	#store the file name entered by the user
my @filedata = ();	#store the file data here
my $in_sequence = 0; 	#Have not seen the sequence yet
my ($line) = "";	#variable to store file line of file data, respectively.

my $seq = "";
my $subseq = "";
#########################
print "Enter the list of the genbank files\n";
$list = <STDIN>;
chomp($list);
open (gbk, "$list") || die ("does not exist\n"); # The file 'list' contains all the *.gbk file names
@gbkfiles = <gbk>;

foreach $filename (@gbkfiles) 
{
@Gene_St = ();
@Gene_En = ();
@Strand = ();

chomp($filename);
print STDERR "Processing file:",$filename, "\n\n";

	unless( open(GET_FILE_DATA, $filename) ) {
		print STDERR "Cannot open file \"$filename\"\n\n";
        	exit;
	}
	$outfile = $filename.".ig";
	$strand = "";
	$found_seq=0;
	$seq = "";
	while ($line = <GET_FILE_DATA>) { #reading the content of the file
		chomp($line);
	             if( $line =~ /^ACCESSION/) 
                      {
			$found_seq=0;
			$line=~s/^ACCESSION\s*//;
			$accn = $line;
		      } 
                    elsif ($line =~ /^LOCUS/)
                      {
                        @locus =  split(/\s+/,$line); 
                      }
                   elsif( $line =~ /gene\s+(complement)?(\()?(\d+)..(\d+)/ ||  $line =~ /gene\s+(complement)?(\()?\<(\d+)..(\d+)/ || $line =~ /gene\s+(complement)?(\()?(\d+)..\>(\d+)/ )# the gene line (comp/simple:withjoin/withoutjoin)
                       {
			if($line =~ /complement/) { $strand = '+1' } else { $strand = '-1';}
			$gene_line = $line;	
			$gene_line =~ (/(\d+)..(\d+)/) || $gene_line =~ (/\<(\d+)..(\d+)/) || $gene_line =~ (/(\d+)..\>(\d+)/);
			$gene_start = $1;
			$gene_end = $2;
			push @Gene_St, $gene_start; #creating the start array
			push @Gene_En, $gene_end; # creating the end array
			push @Strand, $strand;
		     } 

               elsif( $line =~ /^ORIGIN/) 
                {
			$found_seq=1;
			
		} elsif($found_seq) 
                 {
			if( $line =~ /^\/\//) {last;}
			$seq .= $line;# getting the sequence in appended form from the gbk file itself
		} 
	}#end of while loop


close GET_FILE_DATA;
$seq =~ s/[0-9]//g;
$seq =~ s/\s+//g;

 #Sort the Begin and End coordinates sorting by sort command
 @GeneEn = sort {$a<=>$b} @Gene_En;
 @GeneSt = sort {$a<=>$b} @Gene_St;
$cnt1 = @GeneSt;
$cnt2 = @GeneEn;

if($cnt1 >0 and $cnt2 >0){  # even if there is a single gene dif b/w start and begin of gene and end of gene and end of contig is taken

	get_IGenic([@Strand],[@GeneSt],[@GeneEn],$seq,$accn,$outfile);
      
} else {next; }

  print "end:$GeneEn[$cnt-1]\n"; # to get the seq b/w the last element and the end.
  $dif = $locus[2] - $GeneEn[$cnt-1];
  $last_ele  = substr($seq,$GeneEn[$cnt-1],$dif);
   $st_last = $GeneEn[$cnt-1] +1;
   
  print OUT (">last.[$st_last..$locus[2]].$dif\n$last_ele\n");
$seq="";

} #for each gbk file

#################################################

sub get_IGenic {
my(
	$ref_strand,
	$ref_gene_start,  
	$ref_gene_end, 
	$seq, 
	$AccnNo,
	$outfile
	)=@_;
	open (OUT, ">$outfile") || die ("Could not open $outfile to write\n\n");
	@Strand = @$ref_strand;
	@Gene_start = @$ref_gene_start;
	@Gene_end = @$ref_gene_end;


	$NofIGs=0;
        $LastEnd=0;
        for ($q=0;$q<=$#Gene_start;$q++)
                {#Slice Out
                $TempIG = "";
                if ($LastEnd < $Gene_start[$q])
                        {
			$IG_len = $Gene_start[$q]-$LastEnd-1;
                        $TempIG = substr($seq,$LastEnd,$IG_len);
                        if (length($TempIG)>0)
                                {#Write to file
                                $NofIGs++;
                                $tmpbgn=$LastEnd+1;
                                $tmpend=$LastEnd+length($TempIG);
				print OUT ">$AccnNo\[$tmpbgn..$tmpend\],$IG_len\n$TempIG\n";
                                }
                        }
                        $LastEnd = $Gene_end[$q];
                }#End-Slice Out

}
