#####################CREATE DATABASES ALGORITHM and how to use it#################################################################
This folder includes a set of 8 programs all of which are run interactively.On running the perl program, it will ask for input

##################################################################################################################################
Requirements: Download the reference contig files from the NCBI FTP site "ftp://ftp.ncbi.nih.gov/genomes/H_sapiens/" (hs_ref_chrno.gbk and hs_ref_chrno.fa) (where no represents the number from 1 to 22, X,Y)


Preparing the files for creating the databases
#############################################
Make separate folders for each chromosome and transfer the corresponding chromosome's reference genbank and fasta file into it: example for chr1
1. mkdir chr1
2. mv hs_ref_chr1.gbk chr1
3. mv hs_ref_chr1.fa chr1
4. copy all the programs in the CREATE_DATABASE folder into each of the 24 chromosomal folders.

The reference genbank file has the contigs gbk files seperated by "//". Using this seperator the "break_genbank.pl"  will break this into separate genbank files ranging from 0 onwards.

5. Usage: perl break_genbank.pl
input:hs_ref_chr1.gbk
output:chr1.no.gbk (no: number from 0 onwards)
 
The reference fasta file has the contigs fasta files seperated by ">". Using this seperator the "break_fasta.pl"  will break this into separate fasta files ranging from 1 onwards.

6. Usage: perl break_fasta.pl
input:hs_ref_chr1.fa
output:chr1.no.fa (no: number from 1 onwards)

The fasta files have the sequence in form of lines of 70 nt. These have to be put in a single line done by the "fasten_fasta.pl".
Which is automatically done by the "auto_fasten.pl" taking a list of the fasta files.

7.ls chr1.*.fasta > list_chr1_fasta (create a list of the contig fasta files)
8. Usage: perl auto_fasten.pl 
input : list_chr1_fasta
output : chr1.no.fa.red files (no: number from 1 onwards)

The 4 main database creation programs : 
#######################################

1.tRNA_ncRNA_misc_RNA_pick.pl
2.exons_pick.pl

The basic logic of the above two is the same:
a)There are 4 kinds/type of genes: 
-Complement Join (gene with introns on the negative strand) denoted as "revcom" 
-Join (gene with introns on the positive strand) denoted as "join"
-Complement Simple (gene with no introns on the negative strand) denoted as "compsimple"
-Simple (gene with no introns on the positive strand) denoted as "simple"

b)The Complement Join and Join genes are sometimes too long and hence in form of several lines in the gbk files, thus care has to be taken while extracting them.All these conditions are met with in  the program, which is generalised and can be used for any genome.

c)Takes in a list of the genbank files.The output is in two forms : chromosome wise and contig wise. 
(i) ls chr1.*.gbk > chr1_gbks (create a list of the contig genbank files)
(ii) Usage: perl tRNA_ncRNA_misc_RNA_pick.pl / exons_pick.pl
input : chr1_gbks
output: chr1.no.noncoding (contig wise) / chr1.ncrna_trna_miscrna (full chromosome)
        chr1.no.exons                  /  chr1.exons   

d) headers in the output file:
exons_pick.pl -the header contain information on the chrno, contig no, type of rna(mrna/exon),type of gene, gene name,the locus (start and end).
tRNA_ncRNA_misc_RNA_pick.pl -header contains information on the chrno, contig no,type of rna (misc/ncRNA),type of gene, gene name,the locus (start and end). 


The intron program (3.introns_pick.pl)
#####################################
a) Gives introns from two kinds of genes the Complement Join and the  Join genes.
b) Takes in a list of the gbk files
(i) ls chr1.*.gbk > chr1_gbks (create a list of the contig genbank files)
(ii) Usage: perl introns_pick.pl 
input : chr1_gbks
output: chr1.no.introns
c) Gives introns for each contig (contig wise). 
d) These can then be concatenated together to give the entire chromosomal intronic regions
    cat chr1.*.introns >> chr1_introns
e) Header : contains information on the chrno,contig no,type of rna,genename,type of the gene,locus of the intron (start,end)

The intergenic program (4.intergenes_pick.pl)
############################################
a) First orders all the genes to avoid overlaps. Then picks out the intergenes.
b) Takes in a list of genbank files
(i) ls chr1.*.gbk > chr1_gbks
(ii) perl intergenes_pick.pl 
input : chr1_gbks
output:chr1.no.gbk.ig
c) Gives intergenes for each contig (contig wise)
d) These can then be concatenated together to give the entire chromosomal intergenic region
    cat chr1.*.gbk.ig >> chr1_intergenes
e) Header :contains information on the accession no in the gbk file, locus of the intergene (start,end)

Note : the headers in the fasta output files can always be modified 
############################################################################################################################
