#this program is used to break the genbank files appended together in the hs_ref_chrno.gbk file.
#candida
#june 07
#!/usr/bin/perl  

print ("Enter the name of  file you wan to break!\n");
$name = <STDIN>;
open(FIN,"$name") || die "cannot open the file";
$/ = "//";#the genbank files are separated by "//" 
($tmp,$tmp1,$chrext) = split (/\_/,$name);
($chrno,$tmp3) = split (/\./,$chrext);
@contigfile = <FIN>;
chomp(@contigfile);
$len = @contigfile;
for($i=0;$i<$len-1;$i++)
   {
    open(OFIN,">$chrno.$i.gbk") || die "cannot open the file";
    print OFIN ("$contigfile[$i]");
   }
close (FIN);
close (OFIN);
