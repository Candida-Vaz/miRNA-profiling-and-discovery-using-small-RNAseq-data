#this program is used to break the fasta files appended together into separate files
#candida
#june 07
#!/usr/bin/perl  
print ("Enter the name of the fasta file you wan to break!\n");
$name = <STDIN>;
open(FIN,"$name") || die "cannot open the file";
$/ = ">";
(@ar) = split (/\_/,$name);
($chrno,$tmp) = split (/\./,$ar[2]);
@fastafile = <FIN>;
chomp(@fastafile);
$len = @fastafile;
for($i =1; $i <$len;$i++)
   {
     open(OFIN,">$chrno.$i.fasta") || die "cannot open the file";#seperate intergenic region of each contig of a chromosome
     print OFIN (">$fastafile[$i]");
}
close (FIN);
close (OFIN);
