#!/usr/bin/perl
#AUTHOR CANDIDA VAZ
#This program automates the fastenfasta.pl

print "Enter the list of the files to fasten\n";

$name = <STDIN>;

open (IN,"$name");

@arr= <IN>;
chomp(@arr);
foreach $t (@arr)
  {
      system ("perl fastenfasta.pl $t $t.red");
  }

close(IN);
