#this program is used to break the fasta files appended together into separate files
#candida
#june 07
#!/usr/bin/perl  
print ("Enter the name of the file you wan to break!\n");
$name = <STDIN>;
chomp ($name);
open(FIN,"$name") || die "cannot open the file";
$/ = ">";
@fastafile = <FIN>;
chomp(@fastafile);
$len = @fastafile;
for($i=1;$i<$len;$i++)
   {
     open(OFIN,">$name.$i.fasta") || die "cannot open the file";
     print OFIN (">$fastafile[$i]");
}
close (FIN);
close (OFIN);
