#This program is used to find and report those pre-miRNAs that contain the sRNA (putative -miRNA)
#AUTHOR CANDIDA VAZ
#!/usr/bin/perl

$file = @ARGV[0];# the main file having the srna seq in fasta format (obtained from the exon step)

$list = @ARGV[1];#list of all the .red files (extended sequences)

open (IN,"$file");
@arr = <IN>;
chomp(@arr);
$len = @arr;#HAS THE SRNA FASTA FILE

open (LIN,"$list");
@li = <LIN>;#HAS THE RED FILES LIST (Extended sequences)
chomp(@li);

open (OUT,">$file.novel.cases");
print OUT ("****\n");
#######################################For each red file open and check its head matches any of the header of the srna file?####################
foreach $file2(@li)#each.red file (EACH RED FILE)
{
print "the .red file :$file2\n"; 
open (IN2,"$file2");
@arr2 = <IN2>;
@parts = split(/\./,$arr2[0]);
$head = $parts[0].'.'.$parts[1].'.'.$parts[2];#matches the "header" of the srna 
print "the corresp cidmiRNA prediction:$file2.final.fasta\n";
open (IN3,"$file2.final.fasta");#open the final fasta file to check if the predicted hairpin incorporates the srna seq as a subsequence)
@arr3 = <IN3>;#HAS THE CIDMIRNA pred
$seq = $arr3[1];#take the sequence not the str

for($i=0;$i<$len;$i++)
  {
     if($i%2 == 0)
    {
       
       ($unhead,$main)  = split(/\:/,$head);
       $newm  = '>'.$main;
      if(($arr[$i] eq $unhead) ||  ($arr[$i] eq $newm))# checking if the sequence header of the srna seq matches that in the .red fie 
       {
          if($seq =~ /$arr[$i+1]/) #is the srna seq a subseq of the seq predicted as hairpin
            {  
               @srnahead = split(/\./,$arr[$i]);
                @tmp = split(/\>/,$arr2[0]);
                @tmp1 = split(/\,/,$tmp[1]);
               print OUT ("srnaseq:$arr[$i+1]\tLength:$srnahead[1]\tFreq:$srnahead[2]\tsrnaseq_id:chromosomal_pos:$tmp1[0]\nPRECURSOR:Hairpin:pred:@arr3\n****\n");
            }
        }

    }
 }
}
close(LIN);
close(IN);
close(OUT);
#######################################################################################################################################################
