#!/usr/bin/perl
#this program runs the CID-miRNA program 
print "Enter the list of the files to predict miRNA\n";

$name = <STDIN>;
print "$name\n";
chomp($name);
open (IN,$name);
@arr = <IN>;
$len = @arr;
print "$len\n";
chomp(@arr);
open (OUT,">$name.sge_qsub.sh");
print OUT ("#!/bin/sh\n");
print OUT ('#$ -N bCIDMIRNAb',"\n");
print OUT ('#$ -S /bin/sh',"\n");
print OUT ("#"); print OUT ("\$\t"); print OUT ("-cwd\n");
for ($i=0;$i<$len;$i++)
    {
	print OUT ("perl webrouter.pl NOMFOLD BFP:3 LLN:60 HLN:114 CGS:-0.609999 CSS:1 $arr[$i]\n");
    }
close(IN);
close(OUT);
system ("qsub $name.sge_qsub.sh");
