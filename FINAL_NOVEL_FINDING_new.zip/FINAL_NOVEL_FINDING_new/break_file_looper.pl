#!/usr/bin/perl 
#AUTHOR CANDIDA VAZ
#This program is used to break the  files appended together into separate files on the basis of a pattern
$name = @ARGV[0];
chomp($name);
open(FIN,"$name") || die "cannot open the file";
$/ = "****";
@fastafile = <FIN>;
chomp(@fastafile);
$len = @fastafile;
for($i=1;$i<$len;$i++)
   {
     open (OFIN,">$name.$i.fasta") || die "sorry\n";
     print OFIN ("$fastafile[$i]");
}
close (FIN);
close (OFIN);
