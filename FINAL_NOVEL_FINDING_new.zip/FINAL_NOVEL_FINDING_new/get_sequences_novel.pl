#!/usr/bin/perl
#AUTHOR CANDIDA VAZ
#This program takes in the last representative file to give the srnas (putative novel miRNAs)  and their respective precursor sequences

$file = @ARGV[0];# the file containing the unique representative sRNA as novel miRNAs "u_s_sel_mirs.list_correct_isomir_fly_fasta.representatives.matched_only1sel"
open(IN,"$file"),
@arr = <IN>;
chomp(@arr);
$len = @arr;
open(OUT,">$file.srna.precursors");# fasta file comprising of the srna sequences and the precursor sequences of the representatives given in the u_s_sel_mirs.list_correct_isomir_fly_fasta.representatives.matched_only1sel file.

for($i=0;$i<$len;$i++)
 {
 
     @ele = split (/\t/,$arr[$i]);
     open(FIN,"$ele[0]");
     @filesh = <FIN>;
     $lenf = @filesh;
     chomp(@filesh);

      open (FI,">$ele[0].seq");
      open (FIP,">$ele[0].prec");

     for($j=0;$j<$lenf;$j++)
     {
        if($filesh[$j] =~ $ele[1] && $filesh[$j] !~ /PRECURSOR/)
          {
             @f = split(/\t/,$filesh[$j]);
             print FIP ("$ele[1]:$f[0]\n");
          }
        if($filesh[$j] =~ /$ele[5]/)
         {
           ($tmp1,$seq) = split(/\s+/,$filesh[$j+1]);
           print FI ("$seq\n");
         }
     
    }
        system("sort $ele[0].prec > $ele[0].prec.sort");
        system("uniq $ele[0].prec.sort > $ele[0].prec.sort.uniq");
        system("sort $ele[0].seq > $ele[0].seq.sort");
        system("uniq $ele[0].seq.sort > $ele[0].seq.sort.uniq");

       open (SURE,"$ele[0].seq.sort.uniq");
        @r = <SURE>;
        chomp(@r);
       open (SUPE,"$ele[0].prec.sort.uniq");
        @p = <SUPE>;
        chomp(@p);
       $q=@r;
       $w=@p;
               
           (@ele) = split(/\:/,$p[0]);
            $id = $ele[0];
           print OUT (">$id.srnaseq\n$ele[2]\n>$id.precursor\n$r[0]\n");
         

close(FIN);
close(FI);
close(FIP);
}

close(IN);
close(OUT);
