#!/usr/bin/perl
#AUTHOR CANDIDA VAZ
#This program finds for star sequences and isomiRs 

$file = @ARGV[0];# list of the correct isomiR family files (on breaking the "correct.mod.iso" file) #list_correct_isomir_fly_fasta 
open(FIN,"$file");
@arr = <FIN>;
chomp(@arr);
$p = @arr;
open (MEE,">check_for_ismr_stars_novel_mirnas");# THe Major output file that contains the novel mirna , its isomirs and stars if present
for ($i=0;$i<$p;$i++)
  {
     open (IN,"$arr[$i]");
     @arr1 = <IN>;
     chomp(@arr1);

     open (STR,">$arr[$i].star");
     open (ISMR,">$arr[$i].ismr");

     @l = ();
     @fr = ();
     @hyb = ();
     @comp = ();
     @rep_only = ();
     $lenf = @arr1;
     @structure = ();
#####################################getting out the seq,length,freq id ###############################################################################
   for ($k=0;$k<$lenf;$k++)
     {
       if($arr1[$k] =~ /seq/)
         {
          
           ($srna,$length,$freq,$det) = split (/\t/,$arr1[$k]);
           @ele = split (/\:/,$det);
           $no = @ele;
           if($no==4)
             {
                @sl = split(/\./,$ele[3]);
                $idd= 'ID'.'.'.$sl[0].'.'.$sl[1].'.'.$sl[2];
             }

          else
            {
               @sl = split(/\./,$ele[2]);
               $idd = 'ID'.'.'.$sl[0].'.'.$sl[1].'.'.$sl[2];
            }
            
           ($tmp,$seq) = split(/\:/,$srna);
           ($tmp1,$freq) = split(/\:/,$freq);
           ($tmp2,$length) = split(/\:/,$length);
           $hybo = $seq.':'.$freq.':'.$idd;

           push (@l,"$length");
           push (@fr,"$freq");
           push(@hyb,"$hybo");
        }

      }
            @score = split(/\s/,$arr1[2]);
            $NGS = $score[4];
            $SS  = $score[5];
            $prec = $arr1[3];#precursor sequence
            push (@structure,$arr1[4]);
            push (@structure,$arr1[5]);
            push (@structure,$arr1[6]);
            push (@structure,$arr1[7]);
            push (@structure,$arr1[8]);
           
        
######################################################################################################################################################
           
           @sfr = sort {$a<=>$b} @fr;
           $len = @sfr;
           $sel = $sfr[$len-1];#########chosing the representative ######having the highest freq########################
           @comp = ();
           foreach $e (@hyb) 
           {
             
              ($s,$f,$ids) = split (/\:/,$e);
               if($f == $sel)
                {
                  
                   push(@rep_only,"$s");
                   push(@rep_only,"$ids");
                }
              else
               {
                    push(@comp,"$s");
                    push(@comp,"$ids");
               }
           }
 #######################################################################################################################################################
 
              $qrep = @rep_only;
              $qcomp = @comp;
#in case all the members of that fly have the same freq then $qcomp will be 0#############################
# if not then compare with the rep to see if they are isomirs or stars###############
          
              if($qcomp != 0)
             {
                  if($qrep == 2)
               {
                 for($z=0;$z<$qcomp;$z++)
                   {
                      if($comp[$z] !~ /ID/)
                      {
                          $posrep = index($prec,$rep_only[0]);
                          $posz = index($prec,$comp[$z]);
                          $diff = abs ($posrep - $posz);
                           if ($diff >= 27)
                          { 
                            print STR  ("Minor/Star:$comp[$z+1]\t$comp[$z]\n");#star case
                          }
                          else
                          {
                             print ISMR ("Putative(mature miR):$rep_only[1]\t$rep_only[0]\nisomiR:$comp[$z+1]\t$comp[$z]\n");#IsomiR case
                          }
                     }
                  }
               }
                 else
                    {
                        for($z=2;$z<$qrep;$z++)
                        {  
                           
                            if($rep_only[$z] !~ /ID/)
                            { 
                             $posnew_rep = index($prec,$rep_only[0]);
                             $posz = index($prec,$rep_only[$z]);
                             $diff = abs ($posnew_rep - $posz);
                            if ($diff >= 27)
                             { 
                                print STR ("Minor/Star:$rep_only[$z+1]\t$rep_only[$z]\n");#star case
                             }
                          else
                            {
                               if($rep_only[0] ne $rep_only[$z])
                              {
                               print ISMR ("Putative(mature miR):$rep_only[1]\t$rep_only[0]\nisomiR:$rep_only[$z+1]\t$rep_only[$z]\n");#IsomiR case 
                              }
                            }
                         }
                      }

                       for($z=0;$z<$qcomp;$z++)
                       {
                          if($comp[$z] !~ /ID/)
                           {
                            $posrep = index($prec,$rep_only[0]);
                            $posz = index($prec,$comp[$z]);
                            $diff = abs ($posrep - $posz);
                         if ($diff >= 27)
                           { 
                            print STR  ("Minor/Star:$comp[$z+1]\t$comp[$z]\n");#star case
                           }
                           else
                           { 
                              print ISMR ("Putative(mature miR):$rep_only[1]\t$rep_only[0]\nisomiR:$comp[$z+1]\t$comp[$z]\n");#IsomiR case
                           }
                        }
                    } 
  
                 }
             }
         
##########################################################################################################################################################
        else
         {
        
            $new_rep = $rep_only[0];
            if($qrep>2)
            { 
              for($z=2;$z<$qrep;$z++)
                 {
                    if($rep_only[$z] !~ /ID/)
                   { 
                     
                          $posnew_rep = index($prec,$new_rep);
                          $posz = index($prec,$rep_only[$z]);
                           $diff = abs ($posnew_rep - $posz);

                          if ($diff >= 27)
                          { 
                            print STR ("Minor/Star:$rep_only[$z+1]\t$rep_only[$z]\n");#star case
                          }
                          else
                          {
                              print ISMR ("Putative(mature miR):$rep_only[1]\t$new_rep\nisomiR:$rep_only[$z+1]\t$rep_only[$z]\n");#IsomiR case
                          }
                 }
              }
           }
            else
             {
                 print ISMR ("Putative(mature miR):$rep_only[1]\t$new_rep\n");       
             }
         }
#######################################SORTING AND UNIQUING ###########################################################################################
           system("sort $arr[$i].ismr > $arr[$i].ismr.sort");
           system("uniq $arr[$i].ismr.sort > $arr[$i].ismr.sort.uniq");
           system("rm -rf $arr[$i].ismr");
           system("rm -rf $arr[$i].ismr.sort");

           system("sort $arr[$i].star > $arr[$i].star.sort");
           system("uniq $arr[$i].star.sort > $arr[$i].star.sort.uniq");
           system("rm -rf $arr[$i].star");
           system("rm -rf $arr[$i].star.sort");
#######################################################################################################################################################
           
           open (ISU,"$arr[$i].ismr.sort.uniq");
           @asu = <ISU>;
           chomp(@asu);
           $lasu = @asu; 
           print MEE ("###############################################################################################################################\n"); 
           print MEE ("file:$arr[$i]\nprec:$prec\n$NGS\n$SS\n");

           foreach $line(@structure)
          {
            chomp($line);
            print MEE ("$line\n");
          }
   
          if ($lasu >1)
         {
             foreach $e (@asu)
             { 
                print MEE ("$e\n");
             }
               print MEE ("*****\n");
         }
       elsif ($lasu ==1)
         {
           foreach $e (@asu)
             {
                print MEE ("$e\n");
             }
              print MEE ("NO IsomiRs\n");
              print MEE ("*****\n");
         }
      else
         {
             print MEE ("Putative(mature miR):$rep_only[1]\t$rep_only[0]\n");
             print MEE ("No IsomiRs\n"); 
             print MEE ("*****\n");
         }
          
           open (SU,"$arr[$i].star.sort.uniq");
           @bsu = <SU>;
           chomp(@bsu);
           $lbsu = @bsu;

            if($lbsu > 0)
          {
            foreach $e (@bsu)
             {  
                print MEE ("$e\n");
             }
              
          }
         else
          {
            print MEE ("No Star/Minor found\n");
          }
###########################################################################################################################################################
$count =0;
$tot_freq=0;
$iso_score=0;
$freq_score=0;
$GMscore=0;
$starscore=0;
$Final_Score=0;

 foreach $r (@asu)
  {
    $count++;
    ($tmp,$sid) = split(/\:/,$r);
    ($d,$tmp1) = split(/\s+/,$sid);
    @elem = split(/\./,$d);
   $tot_freq = $tot_freq+$elem[3];
  }
if ($count >= 2)
 {
   $iso_score++;
 }
if($tot_freq >= 10)
 {
   $freq_score++;
 }
if($NGS >-0.60)
 {
  $GMscore++;
 }

if ($lbsu >0)
 {
  $starscore=$starscore+2;
 }

$Final_Score =$iso_score+$freq_score+$GMscore+$starscore;

print MEE ("SCORE:$Final_Score\n");
 close(IN);
 close(ISMR);
 close(STR);
 close(ISU);
 close(SU);
#############################################################################################################################################################
 
}

close (FIN);
close(MEE);
############################################################################################################################################
