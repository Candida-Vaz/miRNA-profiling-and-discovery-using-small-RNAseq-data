#!/usr/bin/perl
#AUTHOR CANDIDA VAZ
#This program takes in the total .novel.cases file as input and gives the final list of novel miRNAS as the output.

$file = @ARGV[0];#Enter the output of the discover_novel.pl program
system ("perl break_file_looper.pl $file"); # prog1 
system ("ls *.fasta > list_fasta");
system ("perl looper_latest_cid.pl list_fasta");#prog2
print "1.Looper checking done\n";
system ("grep -B 11 CORRECT list_fasta.novel.analysed > correct");
system ("perl get_srna_prec.pl correct");#prog3
system ("sort precursors > s_precursors");
system ("uniq s_precursors > u_s_precursors");
system ("perl match.pl u_s_precursors correct.mod");#prog4
system ("rm -rf *.fasta");
print "2.Grouping into families done\n";
system ("perl break_last_file.pl correct.mod.iso");#prog5
system ("ls *.fasta > list_correct_isomir_fly_fasta");
system ("perl pick_representatives_cid.pl list_correct_isomir_fly_fasta");#prog6
system ("rm -rf *.sort");
system ("rm -rf *.uniq");
system ("rm -rf *.tmp");
system ("rm -rf *.score");
print "3.Getting the representatives done\n";
system ("perl cut.pl list_correct_isomir_fly_fasta.representatives");#prog7
system ("sort sel_mirs > s_sel_mirs");
system ("uniq s_sel_mirs > u_s_sel_mirs");
system ("perl extract_rep1.pl u_s_sel_mirs list_correct_isomir_fly_fasta.representatives");#prog8
system ("rm -rf *.sort");
system ("rm -rf *.tmp");
system ("perl get_sequences_novel.pl u_s_sel_mirs.list_correct_isomir_fly_fasta.representatives.matched_only1sel");#prog9
print "4.Getting the sequences of all the putative novel mirnas and their precursors done\n";
system ("rm -rf *.seq");
system ("rm -rf *.prec");
system ("rm -rf *.sort");
system ("rm -rf *.uniq");
system ("cut -f 1 u_s_sel_mirs.list_correct_isomir_fly_fasta.representatives.matched_only1sel > list_novel_families");
system ("perl get_stars_isomirs.pl list_novel_families");#prog9
system ("rm -rf *.star.sort.uniq");
system ("rm -rf *.ismr.sort.uniq");
print "5.Getting the stars and isomiRs done\n";
############################################################################ 
