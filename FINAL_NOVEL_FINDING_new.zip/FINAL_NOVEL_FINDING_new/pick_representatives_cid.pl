#!/usr/bin/perl
#AUTHOR CANDIDA VAZ
#This program on given an isomiR family picks out the representative from it.

$list = @ARGV[0];# list of the correct isomiR family files (on breaking the "correct.mod.iso" file) #list_correct_isomir_fly_fasta
open(LI,"$list");
@li=<LI>;
chomp(@li);
open(REP,">$list.representatives");#The list of representative novel miRNAs (one with the highest frequency), family wise, with number of isomiRs, total frequency and scores: Grammar score from CID program and the total additive score:score_sum (if total frequency >=10) + score_isomir_star (if number of members >=2) + score_finscore: (if Grammar score > -0.6)

foreach $file(@li)
{

open (IN,"$file");
@arr =<IN>;
chomp(@arr);
$lfile =@arr;

open(OUT,">$file.tmp");
open(OUT1,">$file.score");

for($i=0;$i<$lfile;$i++)
  {
   
      if ($arr[$i] =~ /srnaseq/)
        {
           @ar = split (/\t/,$arr[$i]);       
           @a = split(/\:/,$ar[3]);
           $la = @a;
            if($la ==4)# if rr:exists (-ve match)
               {
                    @e = split (/\./,$a[3]);
                    $idreq = $e[0].'.'.$e[1].'.'.$e[2];
                    print OUT ("$idreq\n");# print the ids of the srna seq
               }
            elsif($la==3)
               {
                    @e = split (/\./,$a[2]);
                    $idreq = $e[0].'.'.$e[1].'.'.$e[2];#print the ids of the srna seq
                    print OUT ("$idreq\n");
               } 
          
 
            ($tempo,$seq) = split(/\s/,$arr[$i+2]);
             @slices  = split(/\s/,$arr[$i+1]);
        
            ($tempor,$score) = split(/\:/,$slices[4]);

             print OUT1 ("$score\n");# printing the score (Normalised grammar score)

       }
  }
######################################################################################################
            system ("sort -n $file.score > $file.score.sort"); #sorting the scores
            open(SCIN,"$file.score.sort");
             @scarr = <SCIN>;
            $lenscarr = @scarr;
             $finscore =  @scarr[$lenscarr -1]; #the best score  
             if($finscore > -0.61) #if score is greater than -0.61 gets a point
              {
                 $score_finscore = 1;
              }
             else
             {
                 $score_finscore =0;
             }    
######################################################################################################
system ("sort -n $file.tmp > $file.tmp.sort");  # sorting the file containing the ids
system ("uniq $file.tmp.sort > $file.tmp.sort.uniq");# getting the uniq file containing the ids.

#####processing the uniq file #######################################################################
open(FIN,"$file.tmp.sort.uniq") or die "sorry\n"; 
@finarr = <FIN>;
chomp(@finarr);

$len_sort_uniq =@finarr; #finding number of members of its family
if($len_sort_uniq >=2) #if number of isomiRs is more than or = to 2 gets a point
 {
   $score_isomir_star = 1;
 }
else
{
  $score_isomir_star =0;
}
@freq =();
@ids =();

foreach $t (@finarr)
   {
     @parts = split(/\./,$t);
     $id = $parts[0].'.'.$parts[1].'.'.$parts[2];
     $freq = $parts[2];
    push(@freq,"$freq");
    push(@ids,"$id");
  }
      @sorted = sort {$a<=>$b}(@freq);
      $lens=@sorted;
      $sumfreq =0;

       foreach $t (@sorted)
            {
               $sumfreq= $sumfreq + $t;# total freq of all its members
            }

        if($sumfreq >=10) # if total freq >=10 gets a point
          {
            $score_sum = 1;
          }
        else
          {
            $score_sum =0;
          }

     $selfreq = $sorted[$lens-1];# the highest frequency among all the members
  $tot_score = $score_sum + $score_isomir_star + $score_finscore;# total score (additive)
            
      for($q=0;$q<$lens;$q++)
        {  
          @tics = split(/\./,$ids[$q]);
          if ($selfreq == $tics[2])
           {
              print REP ("$file\t$ids[$q]\t$len_sort_uniq\t$selfreq\t$sumfreq\t$finscore\tSCORE:$tot_score\n");
              last;
          }
         else
           {
                next;
           }
        }

    close(IN);
    close(OUT);
    close(OUT1);
    close(SCIN);
    close(FIN);
}
close(LI);
close(REP);
############################################################################################################
