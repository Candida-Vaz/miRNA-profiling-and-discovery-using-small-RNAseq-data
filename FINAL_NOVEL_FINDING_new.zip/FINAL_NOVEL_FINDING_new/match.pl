#!/usr/bin/perl
#AUTHOR CANDIDA VAZ
#This program matches the precursor with the file correct.mod to place the correct cases into their respective isomir families.sRNAs falling within the same hairpin are grouped in one family.

$file = @ARGV[0];# the unique file "u_s_precursors" 
$file1 = @ARGV[1];# "correct.mod"
open(IN,"$file");
open(IN1,"$file1");
@arr = <IN>;
@arr1 = <IN1>;
chomp(@arr);
chomp(@arr1);
$len = @arr;
$len1 =@arr1;
open (OUT,">$file1.iso");# the family file 
print OUT ("***********************\n");
for($j=0;$j<$len;$j++)
 {
    for($i=0;$i<$len1;$i++)
      {
        if($arr1[$i] =~ /srnaseq/)
         {
            
           ($tmp,$seq,$tmp1) = split(/\s+/,$arr1[$i+2]);
          if ($arr[$j] =~ /$seq/ or $seq =~ /$arr[$j]/ or $seq eq $arr[$j]) 
               {  
                  print OUT ("$arr1[$i]\n$arr1[$i+1]\n$arr1[$i+2]\n$arr1[$i+3]\n$arr1[$i+4]\n$arr1[$i+5]\n$arr1[$i+6]\n$arr1[$i+7]\n");
               }
        }
      }
     print OUT ("***********************\n");
 }
close(IN);
close(IN1);
close(OUT);   
