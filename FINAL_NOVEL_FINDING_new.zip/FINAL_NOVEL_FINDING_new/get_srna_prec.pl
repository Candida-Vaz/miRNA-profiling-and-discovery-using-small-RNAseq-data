#!/usr/bin/perl
#AUTHOR CANDIDA VAZ
#This program gives the precursor sequence of the correct cases 

$file = @ARGV[0];# the correct file created using the grep -B 11 "CORRECT" command
open(IN,"$file");
open(OUT,">$file.mod");# modified correct file
open(OUT1,">precursors");# the precursors of the correct cases
@arr = <IN>;
chomp(@arr);
$l = @arr;
for($i=0;$i<$l;$i++)
 {
   if ($arr[$i] =~ /srnaseq/)
    {
       print OUT ("$arr[$i]\n$arr[$i+1]\n$arr[$i+2]\n$arr[$i+3]\n$arr[$i+4]\n$arr[$i+5]\n$arr[$i+6]\n$arr[$i+7]\n\n");  
       ($tmp,$seq,$tmp1) = split(/\s+/,$arr[$i+2]);
       print OUT1 ("$seq\n");
    }
 }
close(IN);
close(OUT);
close(OUT1);
