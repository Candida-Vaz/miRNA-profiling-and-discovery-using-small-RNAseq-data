#!/usr/bin/perl
#AUTHOR CANDIDA VAZ
#This program reports the better scoring precursor and its representative miRNA, when there exists more than one precursor containing the same sRNAs. These precursors may vary by one or two nucleotides.

$file1 = @ARGV[0];#the unique list of the representative mirnas "u_s_sel_mirs"
open (IN,"$file1");
@arr = <IN>;
chomp(@arr);
$len = @arr;


$file2 = @ARGV[1];#the representative file "list_correct_isomir_fly_fasta.representatives"
open (IN2,"$file2");
@arr2 =  <IN2>;
chomp(@arr2);
$len2 = @arr2;

open (OUT,">$file1.$file2.matched_only1sel");

FIRST: for($i=0;$i<$len;$i++)
 {
            open (TPM,">$arr[$i].tmp");
             
             SECOND: for($j=0;$j<$len2;$j++)
              {   
                 @el = split(/\t/,$arr2[$j]); 
                
                 if($arr[$i] eq $el[1])
                  { 
                      print TPM ("$arr2[$j]\n");
                  }
              }
                 system ("sort -n -k 6,6 $arr[$i].tmp > $arr[$i].tmp.sort");#sorting on the basis of NGS score
                 open (SORT,"$arr[$i].tmp.sort");
                 @sor = <SORT>;
                 chomp(@sor);
                 $length = @sor;
                 print OUT ("$sor[$length -1]\n");                 
  }
close(IN);
close(IN2);
close(OUT);
#################################################################################
