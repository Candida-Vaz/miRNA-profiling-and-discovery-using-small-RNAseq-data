#!/usr/bin/perl
#AUTHOR CANDIDA VAZ
#This program extracts out the representative sRNAs as mirnas
$file=@ARGV[0];
open(IN,"$file");
@arr = <IN>;
chomp(@arr);
open (OUT,">sel_mirs");
$l = @arr;
for($i=0;$i<$l;$i++)
 {  
    if($i%2==0)
    {
      @ele = split(/\t/,$arr[$i]);
      print OUT ("$ele[1]\n");
    }
 }
close(IN);
close(OUT);
