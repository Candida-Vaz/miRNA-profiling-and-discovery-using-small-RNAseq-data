#!/usr/bin/perl
# AUTHOR CANDIDA VAZ
# This program checks the location of the srna and the loop to group the predictions into correct and error cases

$list = @ARGV[0];#list of the files obtained on breaking the N1_intergenic_nf_6.novel.cases_total / N1_exons_nf_5.novel.cases_total file "list_fasta"
open(LIN,"$list");
@listn = <LIN>;
chomp(@listn);
open (FOUT,">$list.novel.analysed");# the file which classifies the predictions into correct (stem) and the error cases (loop)
##############################here begins processing each file containing the str#####################################
foreach $file (@listn)
{
$loopseq = ();
@pos = ();
@loop = ();
@pl=();
@dip=();#chd here
open (IN,"$file");
@arr = <IN>;
chomp(@arr);
$len =@arr;
for ($z=0;$z<$len;$z++)
{
print FOUT ("$arr[$z]\n");
}               
   @srna = split (/\s/,$arr[1]);###taking in the srna seq
  
   ($tmp,$srnaseq) = split (/\:/,$srna[0]);
   ($tmp2,$Length) = split (/\:/,$srna[1]);#taking in the length
    
############################getting the loop seq out of the str####################################################3
    @s3= split(//,$arr[4]);
    @s4= split(//,$arr[5]);
    @s5= split(//,$arr[6]);
    @s6= split(//,$arr[7]);
    @s7= split(//,$arr[8]);

 $l3 = @s3;
 $l4 = @s4;
 $l5 = @s5;
 $l6 = @s6;
 $l7 = @s7;

$countdash =0;
for($h=0;$h<$l3;$h++)
{
if($s3[$h] =~ /\-/)
 {
   $countdash++;
 }
}

for($t=0;$t<$l5;$t++)
{
if($s5[$t] =~ /\|/)    
 {
   push(@pos,$t);
 }
}
$lpos = @pos;

$last = $pos[$lpos -1]; 
for($r=$last+1;$r<=$l3;$r++)
  {   
      if($s3[$r] !~ /\s/)
       {
         
          if($s3[$r] =~ 'u')
          {
           push(@loop,"t");
          }
         else
         { 
          push(@loop,"$s3[$r]");
         }
      }
  }  
for($r=$last+1;$r<=$l4;$r++)
  {
       
    if($s4[$r] !~ /\s/)
       {
         
         if($s4[$r] =~ 'u')
          {
           push(@loop,"t");
          }
         else
         { 
          push(@loop,"$s4[$r]");
         }
      }
  } 
   
for($r=$last+1;$r<=$l5;$r++)
  {

    if($s5[$r] !~ /\s/)
       {
        
         if($s5[$r] =~ 'u')
          {
           push(@loop,"t");
          }
         else
         {
          push(@loop,"$s5[$r]");
         }
      }
  }



for($r=$last+1;$r<=$l6;$r++)
  {
   
      if($s6[$r] !~ /\s/)
       {
          
           if($s6[$r] =~ 'u')
          {
           push(@loop,"t");
          }
         else
         { 
          push(@loop,"$s6[$r]");
         }
        
      }
  } 
for($r=$l7;$r>=$last+1;$r--)
  {
     
     if($s7[$r] !~ /\s/)
       {
          
           if($s7[$r] =~ 'u')
          {
           push(@loop,"t");
          }

         else
         { 
          push(@loop,"$s7[$r]");
         }
      }
  } 

  
 foreach $ele (@loop)
  {
    $loopseq = $loopseq.$ele;
  }

@loop_seq = split ("",$loopseq);
$len_loop_seq = @loop_seq;
$loopseq =~ tr/[a,t,g,c]/[A,T,G,C]/; # for cidmirna keep it on

###########################finding the position of the loop seq and the srna seq in the precursor seq#######################################################################
if ($Length <=24)
  {
   @pl =();
   print FOUT ("LOOP:$loopseq\n");
 
    $pos_srna = index($arr[3],$srnaseq); 
    if($len_loop_seq >=3)
    {   
      $polop = index($arr[3],$loopseq);
     
          while($polop != -1)
           {
             push(@pl,$polop);
             $iter = $polop +1;
             $polop = index($arr[3],$loopseq,$iter);
          }
       $chl = @pl;
     
         if ($chl >1)
        {
          for($g=0;$g<$chl;$g++)
           { 
             $anc =$last - $countdash;
             $dip[$g] = $pl[$g] - $anc;
             if($dip[$g] == 1)
               {
                 $pos_loopseq = $pl[$g];
                 last;
               }
           }
           
       }
      else
       {
          $pos_loopseq =$pl[0];
       }
   }
        else
         {
           print FOUT ("ERROR:LENGTH OF LOOP IS LESS THAN3\n");  
           next;
         }



 $range = $pos_srna + $Length -1;
    $range_loop = $pos_loopseq + $len_loop_seq -1;
    print FOUT ("info:psrna=$pos_srna\tploop=$pos_loopseq\trange_srna=$range\trange_loop=$range_loop\n");
   
   
        if($pos_loopseq >= $pos_srna && $pos_loopseq <= $range) 
        {
                $difls = $range - $pos_loopseq +1;
                if($difls>1)
                 {
                    print FOUT ("ERROR:LOOPY\n"); 
                 }
               else
                {
                    print FOUT ("CORRECT\n");
                }

        }
  
        elsif ($pos_srna >= $pos_loopseq && $pos_srna <=$range_loop)
        {
           $difsr = $range_loop - $pos_srna +1;
                if($difsr>1)
                 {
                   print FOUT ("ERROR:LOOPY\n");
                 }
               else
                {
                   print FOUT ("CORRECT\n");
                }
        }

      
    else
     {
       print FOUT ("CORRECT\n");
     }
 }

}
close(LIN);
close(FOUT);
########################################################################################################################################################################
