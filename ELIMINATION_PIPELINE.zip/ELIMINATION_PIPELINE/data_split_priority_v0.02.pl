#!/usr/bin/perl -w
use strict;
use warnings;

## Splits a large database fasta file into 5MB chunks
## and map the query file to the database.

## priority : a match with least no. of error is reported (max 2 errors).



print "USAGE: ./data_split.pl <datafile> <queryfile>";

#print "./data_split.pl <file> <size> <max_lines> <overlap> <queryfile>";
#if ($ARGV[1] <=0){ die "\nSize shld be greater that zero: $ARGV[1]";}
#$max_size=$ARGV[1];
#$max_lines=$ARGV[2];
#$max_str=$max_size;
#$overlap = $ARGV[3];

my $max_size=5000000;
my $max_lines=500000;
my $max_str=$max_size; #for printing
my $overlap = 50;


my $file_ctr = 0;
my $file_size_ctr =0;
my $shift=0;
my $num_lines=0;


open (INFILE, "<", "$ARGV[0]" ) 
	or die "Could not open file $ARGV[0]: $!";

open (OUTFILE, ">", "$ARGV[0].size_$max_str.ovr_$overlap.out.$file_ctr")
	or die "Could not open file $ARGV[0]: $!";

my $header;

print "\nSplitting Data File ...\n";

while  (my $line = <INFILE>) {
    chomp $line;    
    my $line_len=length($line);
    
    if($line =~ /^\>/){
	$header = $line;
	
    }else{
	$line = uc $line; #convert to uppercase.
	if(defined($header)){
CHECK:	    if($file_size_ctr + $line_len > $max_size){ #line is bigger
		
		
		if($line_len - ($max_size - $file_size_ctr) < $overlap){ #overlap is small, just add the whole line
		    # if($file_size_ctr+$line_len <= $max_size + $margin){ #just a bit bigger
		    print OUTFILE $header.".\[\+$shift\]\n";
		    print OUTFILE $line."\n";
		    $header = undef;
		    $shift=0;
		    
		    close(OUTFILE);
		    $file_ctr+=1;
		    $file_size_ctr = 0;
		     $num_lines=0;
		    open (OUTFILE, ">", "$ARGV[0].size_$max_str.ovr_$overlap.out.$file_ctr")
			or die "Could not open file $ARGV[0]: $!";
		    
		}
		else{
		    print OUTFILE $header.".\[\+$shift\]\n"; #dont undef; needed later
		    print OUTFILE substr($line,0,$max_size - $file_size_ctr);
		    my $overlap_str = substr($line,$max_size - $file_size_ctr,$overlap);
		    print OUTFILE $overlap_str."\n";

		    $shift = $shift + $max_size - $file_size_ctr;
		    $line = substr($line,$max_size - $file_size_ctr);
		    $line_len=length($line);

		    close(OUTFILE);
		    $file_ctr+=1;
		    $file_size_ctr = 0;
		    $num_lines=0;
		    open (OUTFILE, ">", "$ARGV[0].size_$max_str.ovr_$overlap.out.$file_ctr")
			or die "Could not open file $ARGV[0]: $!";
		    goto CHECK;



		}
		
		
		
	}else{
		
	    print OUTFILE $header.".\[\+$shift\]\n";
	    print OUTFILE $line."\n";
	    $file_size_ctr += $line_len;
	    $header = undef;
	    $shift=0;
	    $num_lines++;
	    if($num_lines > $max_lines){
		close(OUTFILE);
		$file_ctr+=1;
		$file_size_ctr = 0;
		$num_lines=0;
		open (OUTFILE, ">", "$ARGV[0].size_$max_str.ovr_$overlap.out.$file_ctr")
		    or die "Could not open file $ARGV[0]: $!";
	    }
	    
	}
    }
}
}


print "\nSplit into ".($file_ctr+1)."parts \nQuery starts ...\n";

my $file=0;
my $query_file=$ARGV[1];
my $found_file_fasta="found.$file.fasta";
my $found_file_txt="found.txt";
my $notfound_file="notfound.$file.fasta";

print "\nPurging $found_file_txt ... \n";
my $echo = `echo > $found_file_txt`;

while($file <= $file_ctr){
print "Searching File:$file ...";
my $cmd = "time ./suffix_tree -R -t $ARGV[0].size_$max_str.ovr_$overlap.out.$file -q $query_file 1>>$found_file_txt\n";
print $cmd;
my $output = `$cmd`;
$file++;
#$query_file="notfound.".($file-1).".fasta"; ## keep the query file same : data_split_priority.pl
#$found_file_fasta="found.$file.fasta";
#$found_file_txt="found.$file.txt"; ## create only one report txt file
#$notfound_file="notfound.$file.fasta";

}



## sort the found.txt file with priority to 
print "\nSorting with priority...\n";
print `sort -t"	" -k1,1 -k 6,6n -k2,2r found.txt 2>>err.txt| sort -t"	" -k1,1 -u > found.priority.txt`;



    
#######CREATE THE FOUND.FASTA AND NOTFOUND.FASTA########
my %header_hash;
my $fasta_header;
my $read_header = 1;

## make hash table of the query file
open (QUERYFILE, "<", "$ARGV[1]" ) 
	or die "Could not open file $ARGV[1]: $!";

while (<QUERYFILE>) {
    my $currLine = $_;
    chomp($currLine);

    if ($read_header == 1 && $currLine =~ /^>/ ){ # read fasta header
	    $fasta_header = $currLine;
	    $read_header = 0;
    }else {
	if ($read_header == 0 && ($currLine =~ /^(A|T|G|C|N|a|t|g|c|n)+$/) ){ # read and verify the sequence chars

	    if(!defined($header_hash{$read_header})){
		$header_hash{$fasta_header} = [$currLine,0];
	    }else{
		($header_hash{$fasta_header}->[1])++;
	    }
	    $read_header = 1;

	}else{
	    print STDERR "\nCould not parse line $.: $currLine";
	    $read_header = 1; # restart 
	}
       
    }    
}

## read found.txt file
open (FOUNDTXTFILE, "<", "found.priority.txt" ) 
	or die "Could not open file found.priority.txt: $!";

while (<FOUNDTXTFILE>) {
    my $currLine = $_;
    chomp($currLine);
    my @read_info = split(/\t/,$currLine);

    ## add the found read header to the hash
    if(defined($read_info[0])) {
	$read_header =  $read_info[0]; # first coloumn gives the read name
	if(!defined($header_hash{$read_header})){
	    die "found_file contains a read not found in the query file.\n";
	}else{
	    ($header_hash{$read_header}->[1]) = 1; ## set the found flag
	}
    }
    
}

## output found.fasta and notfound.fasta
open (FOUNDFASTAFILE, ">", "found.fasta" ) 
	or die "Could not open file found.fasta: $!";
open (NOTFOUNDFASTAFILE, ">", "notfound.fasta" ) 
	or die "Could not open file notfound.fasta: $!";

my $read_head = "";
my $read_freq;

while(($read_head, $read_freq) = each(%header_hash)) {
    
    if($read_freq->[1] == 0){
	print NOTFOUNDFASTAFILE "$read_head\n$read_freq->[0]\n";
    }else{
	print FOUNDFASTAFILE "$read_head\n$read_freq->[0]\n";
    }
}

    
print "\nDone. Check found.priority.txt, found.fasta, notfound.fasta\n"
