#!/usr/bin/perl
#AUTHOR CANDIDA VAZ
#This program is used for removing the adaptors from sequences showing more than two anchors; so all these anchors are checked to see if they are true adaptors and cut accordingly from that location; or if all prove to be non adaptors then the seq is left as a samecase.
#may08

$no = @ARGV[0];
$tag_size = @ARGV[1];
$file = "three_more.$no";#input file

open(IN,"$file") or die "sorry\n";
@arr = <IN>;
chomp(@arr);
$len = @arr;

$adaptor_seq = "TCGTATGCCGTCTTCTGCTTG";
@arr_adaptor = split(//,$adaptor_seq);
$len_adaptor = @arr_adaptor;


open(IN,"$file");
###############################################################
open(FRUM,">3mfront_unmodified.txt_rej.$no");
##############################################################
open(FASTAE,">3mfasta_endcase_selected.$no");
##############################################################
open(OUTS,">3m_samecase_no_adaptor.$no");
##############################################################

for ($t=0;$t<$len;$t++)
    { 
     $a = 0;  
     @pos = ();
     $c =0;
     $match = @ARGV[2]; #match eg.TCGTA, 
     ($freq,$seq) = split (/\s/,$arr[$t]);
     $c = index ($seq,$match);
     
while($c >= 0)
   {
        push(@pos,$c);
        $a=$c+1;
        $c= index($seq,$match,$a);
       
       
   }
        
       $number_mat = @pos;  # getting the number of adaptors
       $not = 0;
#####################same case#########################################################################
       if ($number_mat == 0) 
       {
          
           @same = split(//,$seq);
           $len_same = @same;
   
         print OUTS ("$arr[$t]\n");
          next;
           
       }
#########################################################################################################
      if ($number_mat >= 1)
      {
        for($y =0;$y<$number_mat;$y++)
        { 
            if ($pos[$y] <=6)
            {
             $sim =0;
             $dif =0;
             @ar_ad_front = ();
             @ar_ad_front = split(//,$seq);
             $l_ad_front  = @ar_ad_front;
            
             for($m = 0; $m<$len_adaptor;$m++)
                        {
                           $v = $m+$pos[$y];
                         
                          if($arr_adaptor[$m] eq $ar_ad_front[$v])
                               {
                                  $sim = $sim+1;
                                }
                          else
                             {
                                $dif = $dif+1;
                             }
                       }

                     if ($sim >= 18 )
                        {
                             print FRUM (">$no.$t.$freq.$pos[$y]\n$seq\n");  
                             last;
                         }
                      else
                       {
                          $not = $not+1;
                           next;       
                       }
                        
            }
####################################end case##################################################################
       elsif ($pos[$y]>6)
        {
         
               @check_end = ();
               @ar_ad_end = ();
               $seq_new_after = ();
               @after = ();
                      $dif = 0;
                      $sim = 0;
                      @ar_ad_end = split(//,$seq);
         
                     for($j=$pos[$y];$j<$tag_size;$j++) #33 or 35
                    
                      { 
                         push(@check_end,$ar_ad_end[$j]);
                      }
                        
                     $len_check = @check_end;
                       
                      for($q=0;$q<$len_check;$q++)
                             {
                              
                                   if ($check_end[$q] eq $arr_adaptor[$q])
                                     {
                    
                                         $sim = $sim+1;
                                     }
                               else
                                  {
                                     $dif = $dif+1;
                                  }  
                             } 
                      
                      if($dif <= 3)
                        {
                              for($i=0;$i<$pos[$y];$i++)
                                {
                                    $seq_new_after = $seq_new_after.$ar_ad_end[$i];
                                }
                        
                            @after = split(//,$seq_new_after);
                            $len_seq_new_after = @after;
                         
                           if($len_seq_new_after > 10) 
                             {
                               print FASTAE (">$no.$t.$freq.$len_seq_new_after.3m_ad_end\n$seq_new_after\n");
                             }
                          last;
                       }
                   else
                      {      $not = $not+1;
                             next;   
                       }
                     
                   
                 }
              }
          }

                 if ($not == $number_mat)
                       {
                           print OUTS ("$arr[$t]\n");
                           next;
                       }    
                  
      }    
       close (IN);
       close (OUTS);
       close (FRUM);
       close (FASTAE);
#####################################################################################################################################
