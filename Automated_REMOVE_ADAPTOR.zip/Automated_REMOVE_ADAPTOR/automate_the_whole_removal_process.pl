#!/usr/bin/perl
#AUTHOR CANDIDA VAZ
#This automated program requires two inputs as arguments : the untrimmed file and the length of the tags (33 or 35)

$file = @ARGV[0];#the untrimmed file
$len_tags = @ARGV[1];#the length of the tags
$arguments=@ARGV;
if($arguments==2)
{
 print "Beginning the trimming process\n";
}
else
{
print "Usage: perl automate_the_whole_removal_process.pl <the untrimmed file> <the tag size 33 or 35>\n";
exit;
}
system ("perl remove_first.pl 0 $len_tags $file TCGTA ");
system ("perl automate_remover.pl allow_max_two_priority $len_tags");
system ("perl automate_remover_ab_three.pl allow_max_two_priority $len_tags");
print  ("finished trimming now concatenating\n");
system ("cat 3mfasta_endcase_selected.* >> 3m_END");
system ("cat 3m_samecase_no_adaptor.* >> 3m_same");
system ("cat fasta_endcase_selected.* >> FASTA_ENDCASE");
system ("cat fasta_twocase_selected.* >> FASTA_TWO");
system ("cat midcase.* >> FASTA_MIDCASE");
system ("cat FASTA_ENDCASE FASTA_MIDCASE FASTA_TWO 3m_END >> total_end_mid_two_3m_automated");
print  ("finished concatenating now getting the input files for clustering\n");
system ("grep -v '>' total_end_mid_two_3m_automated > total_end_mid_two_3m_automated_woh ");
system ("sort total_end_mid_two_3m_automated_woh > s_total_end_mid_two_3m_automated_woh");
system ("uniq s_total_end_mid_two_3m_automated_woh > u_s_total_end_mid_two_3m_automated_woh");
print ("DONE NOW USE the total_end_mid_two_3m_automated and u_s_total_end_mid_two_3m_automated_woh file for clustering step");
