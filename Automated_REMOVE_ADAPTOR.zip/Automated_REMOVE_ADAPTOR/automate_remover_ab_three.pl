#!/usr/bin/perl
#AUTHOR CANDIDA VAZ
#This program runs remove_three_more.pl program using the allow_max_two_priority file

$list_comb = @ARGV[0]; #print "enter the file with the 2 mismatches in the first 5 nt of the adaptor\n";
$len_tag = @ARGV[1];#length of the tag
open (IN,"$list_comb") or die "sorry"; 
@arr = <IN>;
chomp(@arr);
$len = @arr;

for($i=0;$i<$len;$i++)
  {  
    system("perl remove_three_more.pl $i $len_tag $arr[$i]"); 
  }
close(IN);
