#!/usr/bin/perl
#AUTHOR CANDIDA VAZ
#This program is the main program that does the work of trimming the adaptors based on their location : This is only for the first case TCGTA
#may08

$no = @ARGV[0];###use this for both the cases
$tag_size = @ARGV[1];
#$in = $no-1;#****for second case onwards ####
#$file = "samecase_no_adaptor.$in"; #for second case onwards input file****
$file = @ARGV[2]; ####use this for the first TCGTA case only ####****

open(IN,"$file") or die "sorry\n";
@arr = <IN>;
chomp(@arr);
$len = @arr;
$adaptor_seq = "TCGTATGCCGTCTTCTGCTTG";
@arr_adaptor = split(//,$adaptor_seq);
$len_adaptor = @arr_adaptor;

open(IN,"$file");
###############################################################
open(FRUM,">front_unmodified.txt_rej.$no");
##############################################################
open(FASTAE,">fasta_endcase_selected.$no");
##############################################################
open(OUTS,">samecase_no_adaptor.$no");
##############################################################
open(FASTAM,">midcase.$no");
###############################################################
open(FASTATWO,">fasta_twocase_selected.$no");
###############################################################
open(OUTTHR,">three_more.$no");
###############################################################

for ($t=0;$t<$len;$t++)
    { 

     $a = 0;  
     @pos = ();
     $c =0;
     $match = @ARGV[3]; #match seq five nt length e.g.TCGTA, ####change to 3 for the TCGTA case for others it will be 2 ### *****
     ($freq,$seq) = split (/\s/,$arr[$t]);
     $c = index ($seq,$match);
    
while($c >= 0)
   {
        push(@pos,$c);
        $a=$c+1;
        $c= index($seq,$match,$a);
       
       
   }
        
       $number_mat = @pos;  # getting the number of adaptors
     
#####################same case#########################################################################
       if ($number_mat == 0) 
       {
          
           @same = split(//,$seq);
           $len_same = @same;
   
                print OUTS ("$freq\t$seq\n");
           
       }
#########################more than one adaptor######################################################
      elsif ($number_mat == 2)
      {
         
            @check_two_fir = ();
            @ar_two = ();
            $seq_new_two_fir = ();
            @two_fir = ();
                      $dif = 0;
                      $sim = 0;
                      @ar_two = split(//,$seq);

                     for($j=$pos[0];$j<$tag_size;$j++) #33 or 35

                      {
                         push(@check_two_fir,$ar_two[$j]);
                      }

                     $len_check = @check_two_fir;

                      for($q=0;$q<$len_adaptor;$q++)
                             {

                                   if ($check_two_fir[$q] eq $arr_adaptor[$q])
                                     {
                                         $sim = $sim+1;
                                     }
                               else
                                  {
                                     $dif = $dif+1;
                                  }
                             }

                             if($dif <= 3)
                                {
                                   for($i=0;$i<$pos[0];$i++)
                                   {
                                      $seq_new_two_fir = $seq_new_two_fir.$ar_two[$i];
                                   }

                                   @two_fir = split(//,$seq_new_two_fir);
                                   $len_seq_new_two_fir = @two_fir;

                                   if($len_seq_new_two_fir >= 10) 
                                       {
                                         print FASTATWO (">$no.$t.$freq.$len_seq_new_two_fir.ad_two1\n$seq_new_two_fir\n");
                                       }
                                }
                          else
                           {               
                                                    
        
                                 @check_two_sec = ();
                                 $seq_new_two_sec = ();
                                 @two_sec = ();
                                 $dif = 0;
                                 $sim = 0;
                              

                                 for($j=$pos[1];$j<$tag_size;$j++) #33 or 35

                                      {
                                        push(@check_two_sec,$ar_two[$j]);
                                      }

                                $len_check = @check_two_sec;

                                for($q=0;$q<$len_check;$q++)
                                     {

                                         if ($check_two_sec[$q] eq $arr_adaptor[$q])
                                            {

                                             $sim = $sim+1;
                                             
                                           }
                                        else
                                          {
                                              $dif = $dif+1;
                                          }
                                    }
                                     if ($dif<=3)
                                        {   
                                             for($i=0;$i<$pos[1];$i++)
                                                {
                                                   $seq_new_two_sec = $seq_new_two_sec.$ar_two[$i];
                                                 }

                                               @two_sec = split(//,$seq_new_two_sec);
                                               $len_seq_new_two_sec = @two_sec;

                                           if($len_seq_new_two_sec >= 10) 
                                                {
                                                   print FASTATWO (">$no.$t.$freq.$len_seq_new_two_sec.ad_two2\n$seq_new_two_sec\n");       
                                                }

                                        }                                               

                                      else
                                        {
                                          print OUTS ("$freq\t$seq\n");
                                        }

                            }
      
                    }


##################################################################################################
      elsif ($number_mat >2)
      {
         print OUTTHR ("$freq\t$seq\n");
         
      }
#########################one adaptor#################################################################
     elsif ($number_mat == 1)
     {    
###########################front case #########################################################################
       if($pos[0] <= 6 )
         {
             $sim =0;
             $dif =0;
             @ar_ad_front = ();
            @ar_ad_front = split(//,$seq);
            $l_ad_front  = @ar_ad_front;
            
             for($m=0; $m<$len_adaptor;$m++)
                        {
                           $v = $m+$pos[0];
                           
                          if($arr_adaptor[$m] eq $ar_ad_front[$v])
                               {
                                 
                                  $sim = $sim+1;
                                }
                          else
                             {
                                $dif = $dif+1;
                             }
                       }

                     if ($sim >= 18 )
                        {
                             print FRUM (">$no.$t.$freq.$pos[0]\n$seq\n");  
                         }
                      else
                       {
                          print OUTS ("$freq\t$seq\n");       
                       }
                        
         }
####################################end case##################################################################
       elsif ($pos[0]>=12)
        {
            
           @check_end = ();
           @ar_ad_end = ();
           $seq_new_after = ();
           @after = ();
                      $dif = 0;
                      $sim = 0;
                      @ar_ad_end = split(//,$seq);
         
                     for($j=$pos[0];$j<$tag_size;$j++)# 33 or 35
                    
                      { 
                         push(@check_end,$ar_ad_end[$j]);
                      }
                        
                     $len_check = @check_end;
                       
                      for($q=0;$q<$len_check;$q++)
                             {
                              
                                   if ($check_end[$q] eq $arr_adaptor[$q])
                                     {
                    
                                         $sim = $sim+1;
                                       
                                     }
                               else
                                  {
                                     $dif = $dif+1;
                                  }  
                             } 
                      
                      if($dif <= 3)
                        {
                              for($i=0;$i<$pos[0];$i++)
                                {
                                    $seq_new_after = $seq_new_after.$ar_ad_end[$i];
                                }
                        
                            @after = split(//,$seq_new_after);
                            $len_seq_new_after = @after;
                         
                           if($len_seq_new_after >= 10) 
                             {
                              
                               print FASTAE (">$no.$t.$freq.$len_seq_new_after.ad_end\n$seq_new_after\n");
                             }
                       }
                   else
                      {    
                                 print OUTS ("$freq\t$seq\n");      
                       }
            
        }
           
##############################################mid  case###################################################################
            else
               {
                  
          
           @check_mid = ();
           @ar_ad_mid = ();
           $seq_new_mid = ();
           @mid = ();
                      $dif = 0;
                      $sim = 0;
                      @ar_ad_mid = split(//,$seq);
                     
                     for($j=$pos[0];$j<$tag_size;$j++) # 33 or 35
                    
                      { 
                         push(@check_mid,$ar_ad_mid[$j]);
                      }
                        
                     $len_check = @check_mid;
                       
                      for($q=0;$q<$len_adaptor;$q++)
                             {
                              
                                   if ($check_mid[$q] eq $arr_adaptor[$q])
                                     {
                                         $sim = $sim+1;
                                     }
                               else
                                  {
                                     $dif = $dif+1;
                                  }  
                             } 
                      
                      if($sim>=18)
                         {     
                              for($i=0;$i<$pos[0];$i++)
                                {
                                    $seq_new_mid = $seq_new_mid.$ar_ad_mid[$i];
                                }
                        
                            @mid = split(//,$seq_new_mid);
                            $len_seq_new_mid = @mid;
                         
                          if($len_seq_new_mid >= 10) 
                            {  
                               print FASTAM (">$no.$t.$freq.$len_seq_new_mid.ad_mid\n$seq_new_mid\n");
                            }
                       }
                   else
                      {         
                                 print OUTS ("$freq\t$seq\n");        
                       }        
               }

     }

     
}     

close(IN);
close(FRUM);
close(FASTAE);
close(OUTS);
close(OUTHR);
close(FASTAM);
close(FASTATWO);
############################################################################################################################
