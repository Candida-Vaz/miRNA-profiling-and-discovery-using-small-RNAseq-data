#!/usr/bin/perl
#AUTHOR CANDIDA VAZ
#This program runs the remove_after_1.pl using the allow_max_two_priority file

$list_comb = @ARGV[0]; #enter the file with the 2  mismatches in the first 5 nt of the adaptor
$len_tag = @ARGV[1];#length of the untrimmed tag 33 or 35 ?
chomp($list_comb);
open (IN,"$list_comb") or die "sorry";
@arr = <IN>;
chomp(@arr);
$len = @arr;
for($i=1;$i<$len;$i++)
  {  
    system("perl remove_after_1.pl $i $len_tag $arr[$i]"); 
  }
close(IN);
